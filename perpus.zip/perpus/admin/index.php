<?php 
session_start();
include "lib/koneksi.php";
$set=mysql_fetch_array(mysql_query("select * from setting"));
$user=mysql_fetch_array(mysql_query("select * from user"));
if(!isset($_SESSION['login'])){
header('location:login');
} if ($set[4]==0){
$ip = $_SERVER['REMOTE_ADDR'];
$row=mysql_num_rows(mysql_query("select * from ip where ip='$ip' && status='1'"));
if($row!=1){
    session_destroy();
header('location:login');
	}
}?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Perpus v3.1</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- DATA TABLES -->
    <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css" />
    <!-- Moris Chart -->
    <link href="plugins/morris/morris-0.4.3.min.css" rel="stylesheet" type="text/css">
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- jquery UI -->
    <link href="dist/js/ui/jquery-ui.css" rel="stylesheet" type="text/css" />
  </head>
  <body class="skin-<?php echo "$user[3]"?> <?php echo "$user[4]"?>">
    
          <!-- REQUIRED JS SCRIPTS -->
    
    <!-- jQuery 2.1.3 -->
    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- DATA TABES SCRIPT -->
    <script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- Page-Level Plugin Scripts - Dashboard -->
    <script src="plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="plugins/morris/morris.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- ChartJS 1.0.1 -->
    <script src="plugins/chartjs/Chart.min.js" type="text/javascript"></script>
    <!-- JQuery UI -->
    <script src="dist/js/ui/jquery-ui.js" type="text/javascript"></script>
      <!-- AdminLTE for demo purposes -->
    <!-- <script src="dist/js/demo.js" type="text/javascript"></script> -->
      
      <div class="wrapper">
        
      <!-- Main Header -->
      <header class="main-header">
        <!-- Logo -->
        <a href="home" class="logo"><b>Perpus </b><small>v3.1</small></a>

        <!-- Header Navbar -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->
              <li class="dropdown messages-menu">
                <!-- Menu toggle button -->
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <i class="fa fa-bell-o"></i>
<?php
if(mysql_num_rows(mysql_query("select * from trans where status='pinjam'"))){
$q1=mysql_query("select kelas.*, buku_kelas.*, trans.*, siswa.*, buku.* from kelas, buku_kelas, trans, siswa, buku where kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='pinjam' order by id limit 7");
$telat1=mysql_fetch_array($q1);
$sekarang1 = date ("d-m-Y");
$p1= explode ("-", $telat1['tgl_kembali']);
$d1 = (isset($p1[0]));
$m1 = (isset($p1[1]));
$y1 = (isset($p1[2]));
$p21= explode ("-", $sekarang1); 
$d21 = $p21[0];
$m21 = $p21[1];
$y21 = $p21[2];
$date11 = gregoriantojd($m1, $d1, $y1);
$date21 = gregoriantojd($m21, $d21, $y21);
$selisih1=$date21-$date11;
if($selisih1>=1){
?><span class="label label-danger">!</span><?php }else{echo "";}}?>
                
                  </a>
                <ul class="dropdown-menu">
                  <li class="header label-danger">Transaksi Terlambat</li>
                  
<?php 
$q=mysql_query("select kelas.*, buku_kelas.*, trans.*, siswa.*, buku.* from kelas, buku_kelas, trans, siswa, buku where kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='pinjam' order by id limit 7");
while($telat=mysql_fetch_array($q)){
$sekarang = date ("d-m-Y");
$p= explode ("-", $telat['tgl_kembali']);
$d = $p[0];
$m = $p[1];
$y = $p[2];
$p2= explode ("-", $sekarang); 
$d2 = $p2[0];
$m2 = $p2[1];
$y2 = $p2[2];
$date1 = gregoriantojd($m, $d, $y);
$date2 = gregoriantojd($m2, $d2, $y2);
$selisih=$date2-$date1;
if($selisih>=1){
?>
                <li>
                    <ul class="menu">
                         <li>
                        <a href="#">
                          <div class="pull-left">
                              <?php if($telat['foto_siswa']!=""){?>
                            <img src="foto/<?php echo $telat['foto_siswa']?>" class="img-circle" alt="User Image"/>
                          <?php }else{?><img src="foto/0.png" class="img-circle" alt="User Image"/><?php }?>
                          </div>
                          <h4>                            
                              <b><?php echo strtolower($telat['nama_siswa'])?></b>
                            <small class="text-red"><i class="fa fa-clock-o"></i> <?php echo $selisih?></small>
                          </h4>
                          <p><?php echo strtolower($telat['judul'])?></p>
                        </a>
                      </li>
                    </ul>
                  </li> 
<?php }else{
    echo"";}}?><a href="transaksi_terlambat"><li class="footer text-center">Lihat Semua <i class="fa fa-arrow-circle-right"></i></li></a>
                </ul>
              </li>
              <!-- Menu -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="<?php echo "foto/$user[1]"?>" class="user-image" alt="User Image"/>
                  <i class="fa fa-caret-down"></i>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="<?php echo "foto/$user[1]"?>" class="img-circle" alt="User Image" />
                    <p>
                        <b>SMKN 2 PRAYA TENGAH</b>
                            <small>Jl. Pejanggik No. 9 Praya. 83512</small>
                    </p>
                  </li>
                  <!-- Menu Body -->
                  <li class="user-body">                    
                      <div class="col-xs-4 text-center">
                        <a href="mailto:gl3n@outlook.com"><small class="text-green"><i class="fa fa-upload"></i> Bug Report</small></a>
                    </div>
                      <div class="col-xs-4 text-center">
                        <a href="setting"><small class="text-orange"><i class="fa fa-gears"></i> Setting</small></a>
                    </div>
                      <div class="col-xs-4 text-center">
                        <a href="about"><small class="text-blue"><i class="fa fa-comment"></i> About</small></a>
                    </div>
                  </li>
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="mailto:gl3n@outlook.com" class="btn btn-default text-red btn-sm btn-flat"><i class="fa fa-bug"></i> BUG</a>
                    </div>
                    <div class="pull-right">
                      <a href="logout" class="btn btn-default btn-sm btn-flat"><i class="fa fa-sign-out"></i> Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
              <!--Menu -->
       
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">

          <!-- search form (Optional) -->
          <form action="cari" method="post" class="sidebar-form">
            <div class="input-group">
              <input type="text" name="cari" class="form-control" placeholder="Cari..." required>
              <span class="input-group-btn">
                <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
              </span>
            </div>
          </form>
          <!-- /.search form -->

          <!-- Sidebar Menu -->
          <ul class="sidebar-menu">
            <li class="header text-center">MENU UTAMA</li>
            <!-- Optionally, you can add icons to the links -->
            <li><a href="home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="treeview">
              <a href="#"><i class="fa fa-user"></i> Anggota <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="tambah_anggota">Tambah anggota</a></li>
                <li><a href="anggota">Lihat anggota</a></li>
                  <li><a href="kelas">Kelas</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-book"></i> Buku <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="tambah_buku">Tambah data</a></li>
                <li><a href="buku">Lihat data</a></li>
                  <li><a href="kelasifikasi">Klasifikasi buku</a></li>
              </ul>
            </li>
            <li class="treeview">
                <a href="#"><i class="fa fa-retweet"></i> Transaksi <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="transaksi_anggota">Transaksi baru</a></li>
                <li><a href="pinjaman">Data pinjaman</a></li>
                <li><a href="histori_transaksi">Histori transaksi</a></li>
                <li><a href="#">Menu Tambahan <i class="fa fa-angle-left pull-right"></i></a>
                  <ul class="treeview-menu">
                <li><a href="pinjaman_kelas">Pinjaman kelas</a></li>
                <li><a href="pinjaman_guru">Pinjaman guru</a></li>
              <li><a href="pinjaman_alumni">Pinjaman alumni</a></li>
              </ul>
                  </li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-warning"></i> Kasus <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="histori_kehilangan">Histori kehilangan</a></li>
                <li><a href="buku_hilang">Daftar buku hilang</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="print"><i class="fa fa-print"></i> Print <span class="label label-success pull-right"><?php echo mysql_num_rows(mysql_query("select kelas.*, buku_kelas.*, trans.*, siswa.*, buku.* from kelas, buku_kelas, trans, siswa, buku where kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='pinjam' || kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='hilang'"));
$no=0;?></span></a>
            </li>
          </ul><!-- /.sidebar-menu -->
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->

            <!-- Main content -->
          
          <?php include ('lib/page.php'); ?>
            
            <!-- /.content -->
    
        </div><!-- /.content-wrapper -->

      <!-- Main Footer -->
      <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
            <strong>Copyright &copy; 2015</strong>
        </div>
        <!-- Default to the left --> 
            <strong><a target="_blank" href="http://facebook.com/rpl2.community">RPL <small>Community</small></a></strong>
      </footer>

    </div><!-- ./wrapper -->
 <script src="dist/js/pages/data.js" type="text/javascript"></script>
  </body>
</html>