<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Laporan Perpus</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body onload="window.print();">
    <div class="wrapper">
      <!-- Main content -->
      <section class="invoice">
        <!-- title row -->
        <div class="row">
          <div class="col-xs-12">
            <h2 class="page-header">
              <i class="fa fa-globe"></i> LAPORAN PERPUSTAKAAN
              <small class="pull-right"><?php echo date("d/m/Y")?></small>
            </h2>
          </div><!-- /.col -->
        </div>
        <!-- info row -->

        <!-- Table row -->
        <div class="row">
          <div class="col-xs-12 table-responsive">
            <table class="table table-striped">
              <thead>
                <tr class="text-center">
                  <th>NO</th>
                  <th>NAMA</th>
                  <th>KELAS</th>
                  <th>STATUS</th>
                  <th>BUKU</th>
                </tr>
              </thead>
              <tbody>
<?php
$qtrans=mysql_query("select kelas.*, buku_kelas.*, trans.*, siswa.*, buku.* from kelas, buku_kelas, trans, siswa, buku where kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='pinjam' || kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='hilang' order by siswa.kelas");
$no=0;
while($trans=mysql_fetch_array($qtrans)){
$no++;
if($trans[7]=='pinjam'){
$status="Pinjam";
}else{
$status="Hilang";
}?> 
<tr class='text-center'>
<td><?php echo $no?></td>
<td><?php echo strtoupper($trans['nama_siswa'])?></td>
<td><?php echo $trans['kelas']?></td>
<td><?php echo $status ?></td>
<td><?php echo $trans['judul'];
?>
</td>
</tr>
<?php }?>
              </tbody>
            </table>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </section><!-- /.content -->
    </div><!-- ./wrapper -->
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
  </body>
</html>