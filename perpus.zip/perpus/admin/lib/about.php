<section class="content-header">
          <h1>
              <b class="text-blue">RPL</b><small>Community</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">About</li>
          </ol>
        </section>
<section class="content">
<br><div class="row">

            <div class="col-md-6">
              <!-- The time line -->
              <ul class="timeline">
                <!-- timeline time label -->
                <li class="time-label">
                  <span class="bg-blue-active">
                    <i class="fa fa-calendar"></i> 2015
                  </span>
                </li>
                <!-- /.timeline-label -->
                <!-- timeline item -->
                <li>
                  <i class="fa fa-bookmark bg-aqua"></i>
                  <div class="timeline-item">
                    <span class="time"><i class="fa fa-calendar"></i> 17 Agustus</span>
                    <h3 class="timeline-header no-border"><a class="text-blue">Perpus v3.1</a> Rilis</h3>
                  </div>
                </li>
                <!-- END timeline item -->
                <!-- timeline item -->
                  <li>
                  <i class="fa fa-asterisk bg-red"></i>
                  <div class="timeline-item">
                    <span class="time"><i class="fa fa-calendar"></i> 6 juli</span>
                      <h3 class="timeline-header"><a class="text-blue">Perpus v3</a> <small>beta</small></h3>
                  </div>
                </li>
                <!-- END timeline item -->
                <!-- timeline time label -->
                <li>
                  <i class="fa fa-gears bg-olive"></i>
                  <div class="timeline-item">
                    <span class="time"><i class="fa fa-calendar"></i> 6 mei</span>
                    <h3 class="timeline-header">Pengerjaan Dimulai <a class="text-blue">Perpus v3</a></h3>
                  </div>
                </li>
                <!-- END timeline item -->
                <!-- timeline time label -->
                <li class="time-label">
                  <span class="bg-blue">
                    <i class="fa fa-calendar"></i> 2014
                  </span>
                </li>
                <!-- /.timeline-label -->
                <!-- timeline item -->
                  <li>
               <i class="fa fa-bookmark bg-aqua"></i>
                  <div class="timeline-item">
                    <span class="time"><i class="fa fa-calendar"></i> 7 Agustus</span>
                    <h3 class="timeline-header no-border"><a class="text-blue">Perpus v2</a> Rilis</h3>
                  </div>
                </li>
                <!-- END timeline item -->
                <!-- timeline item -->
                <li>
                  <i class="fa fa-gears bg-olive"></i>
                  <div class="timeline-item">
                    <span class="time"><i class="fa fa-calendar"></i> 18 Juni</span>
                    <h3 class="timeline-header">Pengerjaan Dimulai <a class="text-blue">Perpus v2</a></h3>
                  </div>
                    <li>
               <i class="fa fa-bookmark bg-aqua"></i>
                  <div class="timeline-item">
                    <span class="time"><i class="fa fa-calendar"></i> 17 April</span>
                    <h3 class="timeline-header no-border"><a class="text-blue">Perpus v0.1</a> Rilis</h3>
                  </div>
                </li>
                </li>
                <!-- END timeline item -->
                   <li class="time-label">
                  <span class="bg-blue disabled">
                    <i class="fa fa-calendar"></i> 2013
                  </span>
                </li>
                <!-- END timeline item -->
                <!-- timeline item -->
                <li>
                  <i class="fa fa-envelope-o bg-maroon"></i>
                  <div class="timeline-item">
                    <span class="time"><i class="fa fa-calendar"></i> 4 Desember</span>
                    <h3 class="timeline-header">Izin aplikasi</h3>
                  </div>
                </li>
                <!-- END timeline item -->
                <li>
                  <i class="fa fa-clock-o bg-gray"></i>
                </li>
              </ul>
            </div><!-- /.col -->

<div class="col-lg-6">
<ul class="timeline">
                <!-- timeline time label -->
                <li class="time-label">
                  <span class="bg-red">
                    <i class="fa fa-bug bg-red"></i> Bug
                  </span>
                </li>
                <!-- /.timeline-label -->
                <!-- timeline item -->
                <li>
                  <i class="fa fa-times bg-red"></i>
                  <div class="timeline-item">
                      <h3 class="timeline-header">Menu <b>passed kelas XII</b></h3>
                    <div class="timeline-body">
                      Jika menu ini digunakan maka kelas X dan kelas XI akan naik kelas secara otomaris, semua kelas XII akan terhapus.<br> setelah menggunakan menu ini semua foto kelas XII tidak terhapus, jadi harus menghapus manual.
                    </div>
                  </div>
                </li>
    <li>
                  <i class="fa fa-times bg-red"></i>
                  <div class="timeline-item">
                    <h3 class="timeline-header">Sebagian data anggota hilang</h3>
                    <div class="timeline-body">
                        Kejadian ini terjadi karena telah menggunakan menu <b>passed kelas XII</b>, untuk menampilkan data itu lagi silahkan menambahkan kelas sesuai data-data yang hilang. contoh kelas X TSM 4 naik kelas, maka kelas XI TSM 4 harus dibuat.
                    </div>
                  </div>
                </li>
              </div>          </div><!-- /.row -->
          <div class="row" style="margin-top: 10px;">
            <div class="col-md-12">
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"><i class="fa fa-code"></i>  RPL Community Angkatan 2012</h3>
                </div>
                <div class="box-body">
                    <p class="text-center"><img src="foto/logo.jpg"></p>
                </div><!-- /.box-body -->
                  <div class="timeline-footer">
                      
                    </div>
              </div><!-- /.box -->
            </div><!-- /.col -->
          

</section>