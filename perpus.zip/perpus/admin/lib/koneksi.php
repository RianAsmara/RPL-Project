<?php
date_default_timezone_set("Asia/Jakarta");
mysql_connect('localhost','root','');
mysql_select_db('perpus') or die("<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"UTF-8\">
    <title>login</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href=\"bootstrap/css/bootstrap.min.css\" rel=\"stylesheet\" type=\"text/css\" />
    <!-- Font Awesome Icons -->
    <link href=\"font-awesome/css/font-awesome.css\" rel=\"stylesheet\" type=\"text/css\" />
    <!-- Theme style -->
    <link href=\"dist/css/AdminLTE.min.css\" rel=\"stylesheet\" type=\"text/css\" />
  </head>
    
  <body class=\"lockscreen\">
    <!-- Automatic element centering -->      
    <div class=\"lockscreen-wrapper\">
      <div class=\"lockscreen-logo\">
          <br><br>
      </div>
      <!-- START LOCK SCREEN ITEM -->
<div class='callout callout-danger'>
<h4><i class=\"fa fa-warning\"></i> connection error</h4>
<p> Database tidak ditemukan <a href=\"\" class=\"alert-link\">Refresh</a></p>
</div>
      </div><!-- /.lockscreen-item -->
     
    </div><!-- /.center -->

    <!-- jQuery 2.1.3 -->
    <script src=\"plugins/jQuery/jQuery-2.1.3.min.js\"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src=\"bootstrap/js/bootstrap.min.js\" type=\"text/javascript\"></script>
  </body>
</html>
");
?>