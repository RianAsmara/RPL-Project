<?php

$p=$_GET['p'];

if($p=="home"){
include 'lib/home.php';
}

else if($p=="anggota"){
include '_anggota/lihat_a.php';
}else if($p=="tambah_anggota"){
include '_anggota/tambah_a.php';
}else if($p=="kelas"){
include '_anggota/kelas.php';
}

else if($p=="buku"){
include '_buku/lihat_b.php';
}else if($p=="tambah_buku"){
include '_buku/tambah_b.php';
}else if($p=="kelasifikasi"){
include '_buku/buku_kelas.php';
}else if($p=="buku_hilang"){
include '_buku/hilang_b.php';
}

else if($p=="pinjaman"){
include '_transaksi/lihat_t.php';
}else if($p=="pinjaman_kelas"){
include '_transaksi/lihat_t2.php';
}else if($p=="pinjaman_guru"){
include '_transaksi/lihat_t3.php';
}else if($p=="read_list"){
include '_transaksi/red_list.php';
}else if($p=="histori_transaksi"){
include '_transaksi/lihat_h.php';
}else if($p=="transaksi"){
include '_transaksi/tambah_t.php';
}else if($p=="transaksi_terlambat"){
include '_transaksi/lihat_t4.php';
}else if($p=="alumni"){
include '_transaksi/lihat_t5.php';
}

else if($p=="about"){
include 'lib/about.php';
}else if($p=="logout"){
include 'lib/logout.php';
}else if($p=="cari"){
include 'lib/cari.php';
}else if($p=="set"){
include 'lib/set.php';
}else if($p=="print"){
include 'lib/print.php';
}

else { ?>
<script>document.location='home'</script>
<?php } ?>