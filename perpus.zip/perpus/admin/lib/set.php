<section class="content-header">
          <h1>
              <i class="fa fa-gears fa-fw"></i><small><b>PENGATURAN</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Pengaturan</li>
          </ol>
        </section>
<section class="content">
<?php
if(isset($_POST['delete_master_buku'])){

$query = mysql_query("delete from buku");
if($query){ 
    echo "<h5><div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Master data <label><em>buku</em></label> berhasil dihapus
</div></h5>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div></h5>";
}}

if(isset($_POST['delete_master_anggota'])){

$query = mysql_query("delete from siswa");
if($query){ 
    echo "<h5><div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Master data <label><em>anggota</em></label> berhasil dihapus
</div></h5>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div></h5>";
}}

if(isset($_POST['excel_buku'])){
include "lib/excel_reader2.php";
$data = new Spreadsheet_Excel_Reader($_FILES['excel']['tmp_name']);
$hasildata = $data->rowcount($sheet_index=0);

for ($i=1; $i<=$hasildata; $i++)
{
  $data1 = $data->val($i,1); 
  $data2 = $data->val($i,2);
  $data3 = $data->val($i,3);
  $data4 = $data->val($i,4); 
  $data5 = $data->val($i,5);
  $data6 = $data->val($i,6);
  $data7 = $data->val($i,7);
  $data8 = $data->val($i,8);
  $data9 = date ("d-m-Y");
$query = mysql_query("INSERT INTO buku VALUES ('$data1','$data2','$data3','$data4','$data5','$data6','$data7','$data8','$data9','1')");
}
if($query){ 
    echo "<h5><div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Data <label><em>buku</em></label> berhasil diexport
</div></h5>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div></h5>";
}}

if(isset($_POST['excel_anggota'])){
include "lib/excel_reader2.php";
$data = new Spreadsheet_Excel_Reader($_FILES['excel']['tmp_name']);
$hasildata = $data->rowcount($sheet_index=0);

for ($i=1; $i<=$hasildata; $i++)
{
  $data1 = $data->val($i,1); 
  $data2 = $data->val($i,2);
  $data3 = $data->val($i,3);
  $data4 = $data->val($i,4); 
  $data5 = $data->val($i,5);
  $data6 = $data->val($i,6);
  $data7 = $data->val($i,7);
$query = mysql_query("INSERT INTO siswa  VALUES ('$data1','$data2','$data3','$data4','$data5','$data6','$data7')");
}
if($query){ 
    echo "<h5><div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Data <label><em>anggota</em></label> berhasil diexport
</div></h5>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div></h5>";
}}

if(isset($_POST['allow_ip'])){
    $a=$_POST['ip'];
    $q=mysql_query("select * from ip where ip='$a'");
    $row=mysql_num_rows($q);
    if($row==1){
        echo "<div class='alert alert-warning alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
IP \"$a\" sudah masuk dalam daftar.
</div>";
    }else{
        mysql_query("insert into ip value(NULL,'$a','1')");
        echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
IP \"$a\" masuk daftar allow.
</div>";
    }}
if(isset($_POST['update_set'])){
    $a=$_POST['denda'];
    $b=$_POST['batas_buku'];
    $c=$_POST['batas_pinjam'];
    $d=$_POST['ip'];
    $q=mysql_query("update setting set denda='$a',batas_buku='$b',batas_pinjam='$c',ip='$d' where id='1'");
    if($q){
        echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Pengaturan sistem berhasil diperbaharui.
</div>";
    }}
if(isset($_POST['pass'])){
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII RPL 1'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII RPL 2'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII RPL 3'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TKR 1'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TKR 2'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TKR 3'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TAV 1'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TAV 2'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TAV 3'");    
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TGB 1'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TGB 2'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TGB 3'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TP 1'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TP 2'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TP 3'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TP'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TKK'");    
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TIL'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TSM'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TKK 1'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TKK 2'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TKK 3'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TSM 1'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TSM 2'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TSM 3'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TSM 4'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TIL 1'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TIL 2'");
mysql_query("update siswa set kelas='ALUMNI' where kelas='XII TIL 3'"); 
    
    
mysql_query("update siswa set kelas='XII TP 1' where kelas='XI TP 1'");
mysql_query("update siswa set kelas='XII TP 2' where kelas='XI TP 2'");
mysql_query("update siswa set kelas='XII TP 3' where kelas='XI TP 3'");
mysql_query("update siswa set kelas='XII RPL 1' where kelas='XI RPL 1'");
mysql_query("update siswa set kelas='XII RPL 2' where kelas='XI RPL 2'");
mysql_query("update siswa set kelas='XII RPL 3' where kelas='XI RPL 3'");    
mysql_query("update siswa set kelas='XII TAV 1' where kelas='XI TAV 1'");
mysql_query("update siswa set kelas='XII TAV 2' where kelas='XI TAV 2'");
mysql_query("update siswa set kelas='XII TAV 3' where kelas='XI TAV 3'");    
mysql_query("update siswa set kelas='XII TGB 1' where kelas='XI TGB 1'");
mysql_query("update siswa set kelas='XII TGB 2' where kelas='XI TGB 2'");
mysql_query("update siswa set kelas='XII TGB 3' where kelas='XI TGB 3'");
mysql_query("update siswa set kelas='XII TKR 1' where kelas='XI TKR 1'");
mysql_query("update siswa set kelas='XII TKR 2' where kelas='XI TKR 2'");
mysql_query("update siswa set kelas='XII TKR 3' where kelas='XI TKR 3'");
mysql_query("update siswa set kelas='XII TIL 1' where kelas='XI TIL 1'");
mysql_query("update siswa set kelas='XII TIL 2' where kelas='XI TIL 2'");
mysql_query("update siswa set kelas='XII TIL 3' where kelas='XI TIL 3'");
mysql_query("update siswa set kelas='XII TKK 1' where kelas='XI TKK 1'");
mysql_query("update siswa set kelas='XII TKK 2' where kelas='XI TKK 2'");
mysql_query("update siswa set kelas='XII TKK 3' where kelas='XI TKK 3'");
mysql_query("update siswa set kelas='XII TSM' where kelas='XI TSM'");
mysql_query("update siswa set kelas='XII TIL' where kelas='XI TIL'");
mysql_query("update siswa set kelas='XII TKK' where kelas='XI TKK'");
mysql_query("update siswa set kelas='XII TP' where kelas='XI TP'");
mysql_query("update siswa set kelas='XII TSM 1' where kelas='XI TSM 1'");
mysql_query("update siswa set kelas='XII TSM 2' where kelas='XI TSM 2'");
mysql_query("update siswa set kelas='XII TSM 3' where kelas='XI TSM 3'");
mysql_query("update siswa set kelas='XII TSM 4' where kelas='XI TSM 4'");
       
    
mysql_query("update siswa set kelas='XI RPL 1' where kelas='X RPL 1'");
mysql_query("update siswa set kelas='XI RPL 2' where kelas='X RPL 2'");
mysql_query("update siswa set kelas='XI RPL 3' where kelas='X RPL 3'");
mysql_query("update siswa set kelas='XI TAV 1' where kelas='X TAV 1'");
mysql_query("update siswa set kelas='XI TAV 2' where kelas='X TAV 2'");
mysql_query("update siswa set kelas='XI TAV 3' where kelas='X TAV 3'");
mysql_query("update siswa set kelas='XI TGB 1' where kelas='X TGB 1'");
mysql_query("update siswa set kelas='XI TGB 2' where kelas='X TGB 2'");
mysql_query("update siswa set kelas='XI TGB 3' where kelas='X TGB 3'");
mysql_query("update siswa set kelas='XI TKR 1' where kelas='X TKR 1'");
mysql_query("update siswa set kelas='XI TKR 2' where kelas='X TKR 2'");
mysql_query("update siswa set kelas='XI TKR 3' where kelas='X TKR 3'");
mysql_query("update siswa set kelas='XI TIL 1' where kelas='X TIL 1'");
mysql_query("update siswa set kelas='XI TIL 2' where kelas='X TIL 2'");
mysql_query("update siswa set kelas='XI TIL 3' where kelas='X TIL 3'");
mysql_query("update siswa set kelas='XI TP 1' where kelas='X TP 1'");
mysql_query("update siswa set kelas='XI TP 2' where kelas='X TP 2'");
mysql_query("update siswa set kelas='XI TP 3' where kelas='X TP 3'");
mysql_query("update siswa set kelas='XI TKK 1' where kelas='X TKK 1'");
mysql_query("update siswa set kelas='XI TKK 2' where kelas='X TKK 2'");
mysql_query("update siswa set kelas='XI TKK 3' where kelas='X TKK 3'");
mysql_query("update siswa set kelas='XI TSM 1' where kelas='X TSM 1'");
mysql_query("update siswa set kelas='XI TSM 2' where kelas='X TSM 2'");
mysql_query("update siswa set kelas='XI TSM 3' where kelas='X TSM 3'");
mysql_query("update siswa set kelas='XI TSM 4' where kelas='X TSM 4'");
mysql_query("update siswa set kelas='XI TP' where kelas='X TP'");
mysql_query("update siswa set kelas='XI TKK' where kelas='X TKK'");
mysql_query("update siswa set kelas='XI TIL' where kelas='X TIL'");
mysql_query("update siswa set kelas='XI TSM' where kelas='X TSM'");
    
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Pengaturan passed kelas XII diperbaharui.
</div>";
    }
if(isset($_POST['tampilan'])){
    $a=$_POST['tema'];
    $b=$_POST['layout'];
    $c=$_FILES['file']['name'];
    if($c!=""){
    $foto=mysql_fetch_array(mysql_query("select profile from user"));
    unlink("../foto/$foto[0]");
    move_uploaded_file($_FILES['file']['tmp_name'],"../foto/$c");
    $q=mysql_query("update user set profile='$c', tema='$a', layout='$b' where id='1'") or die (mysql_error());
    if($q){
        echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Tampilan berhasil di ubah, <a class='alert-link' href=''>Refresh</a>
</div>";
    }else{
        echo "<div class='alert alert-warning alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ulangi kembali
</div>";
    }}else{
$q=mysql_query("update user set tema='$a', layout='$b' where id='1'")or die (mysql_error());
 if($q){
        echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Tampilan berhasil di ubah, <a class='alert-link' href=''>Refresh</a>
</div>";
    }else{
        echo "<div class='alert alert-warning alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ulangi kembali.
</div>";
}}}

if(isset($_POST['edit_ip'])){
    $a=$_POST['id'];
    $b=$_POST['ip'];
    $c=$_POST['status'];
    if($a==1 || $a==2){
echo "<div class='alert alert-warning alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
IP <strong>::1 / 127.0.0.1</strong> tidak dapat diubah.
</div>";
    }else{
mysql_query("update ip set ip='$b', status='$c' where id='$a'");
echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
IP \"$b\" berhasil di perbaharui.
</div>";
}}

if(isset($_POST['delete_ip'])){
    $a=$_POST['id'];
    $b=$_POST['ip'];
    if($b=="::1" || $b=="127.0.0.1"){
        echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
IP <strong>::1 / 127.0.0.1</strong> tidak bisa dihapus.
</div>";
    }else{
        mysql_query("delete from ip where id='$a'");
        echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
IP \"$b\" berhasil dihapus dari daftar.
</div>";
    }}

if(isset($_POST['ubah'])){
$p=md5(mysql_real_escape_string($_POST['pass_lama']));
$p2=md5(mysql_real_escape_string($_POST['pass_baru']));
$p3=md5(mysql_real_escape_string($_POST['pass_baru2']));
$pass=mysql_fetch_array(mysql_query("Select * from user"));
if($p!=$pass['password']){
echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Password lama salah.
</div>";
}else if($p2!=$p3){
echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Password baru tidak cocok.
</div>";	
}else if($p==$p2){
echo "<div class='alert alert-warning alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, Password lama dan password baru sama.
</div>";	
}else{
$z=mysql_query("update user set password='$p2' where id='1'");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Password berhasil diganti.
</div>";
}else{   
    echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div>";
}}} ?>

<div class="row">
<div class="col-md-3">
    
              <div class="box box-solid">
                <div class="box-body no-padding">
                  <ul class="nav nav-pills nav-stacked">
                    <li><a href="setting"><i class="fa fa-wrench"></i> Sistem</a></li>
                    <li><a href="ip"><i class="fa fa-sitemap"></i> IP Address</a></li>
                    <li><a href="personalize"><i class="fa fa-desktop"></i> Tampilan</a></li>
                    <li><a href="passed"><i class="fa fa-level-up"></i> Passed kelas XII</a></li>
                    <li><a href="password"><i class="fa fa-lock"></i> Kata Sandi</a></li>
                    <li><a href="import"><i class="fa fa-upload"></i> Import</a></li>
                  </ul>
                </div><!-- /.box-body -->
              </div><!-- /. box -->
<?php if(isset($_POST['edit'])){
    $a=$_POST['id'];
    $b=$_POST['ip'];
    $c=$_POST['status'];
?>
<div class="box box-info">
<form method="post">
    <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
<div class="box-body">
<div class="form-group">
        <label>NO. INDUK</label>
    <input type='hidden' class='form-control' name='id' value='<?php echo $a?>' required><input type='text' class='form-control' name='ip' value='<?php echo $b?>' required></div>
    <div class="form-group">
        <label>NO. INDUK</label>
<select class="form-control" name="status" required>
    <?php if($c==1){
    echo "<option value='1' selected>Allow</option>
    <option value='2'>Block</option>";
    }else{
    echo "<option value='1'>Allow</option>
    <option value='2' selected>Block</option>";
    }
echo "</select></div></div><div class='box box-footer'><button type='submit' class='btn bg-olive' name='edit_ip'>Simpan</button></div></div>
</form> 
";}?>
    </div>   
    
<div class="col-md-9">
<?php
if(isset($_GET['ref'])){
$ref=$_GET['ref'];
if($ref=="password"){
?>
<div class="box box-danger">
<div class="box-header">
    <h3 class="box-title"><li class='fa fa-lock'></li> <small>GANTI KATA SANDI</small></h3>
</div>
<form role='form' method='post'>    
<div class="box-body">
 <div class="form-group">
        <label>KATA SANDI LAMA</label>
        <input type="password" class="form-control" name="pass_lama" autofocus required>
    </div>
     <div class="form-group">
        <label>KATA SANDI BARU</label>
        <input type="password" class="form-control" name="pass_baru" required>
    </div>
     <div class="form-group">
        <label>ULANGI KATA SANDI</label>
        <input type="password" class="form-control" name="pass_baru2" required>
    </div>
</div>
    <div class="box-footer"><button type="submit" name="ubah" class="btn btn-primary"> Ganti</button></div>
</form>                         
</div>
<?php }else if($ref=="ip"){
?><div class="box box-info">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="Dtable" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>IP</th>
                        <th>STATUS</th>
                        <th>ACTION</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
$q=mysql_query("select * from ip");
while($data=mysql_fetch_array($q)){
if($data[2]==1){
    $status="<lablel class='label bg-primary'>Allow</label>"; 
    $warna="";
}else{
    $status="<label class='label bg-red'>block</label>";
    $warna="warning";
}
echo "
<tr class='text-center $warna'><form method='post'>
    <td><input type='hidden' name='id' value='$data[0]'>$data[1]<input type='hidden' name='ip' value='$data[1]'></td>
    <td>$status<input type='hidden' name='status' value='$data[2]'></td>
    <td><button type='submit' name='edit' class='btn bg-olive btn-flat btn-xs'><i class='fa fa-edit'></i></button>
        <button type='submit' name='delete_ip' class='btn btn-xs btn-flat bg-red' onclick='return confirm(\"Anda yakin ingin menghapus ip $data[1]  ?\")'><i class='fa fa-trash-o'></i></button>
    </td></form>
</tr>
";
}
echo"</tbody>
</table>
</div>
</div>
<form method='post'>
<div class='form-group input-group'>
<input type='text' name='ip' class='form-control'>
<span class='input-group-btn'>
<button class='btn btn-primary' type='submit' name='allow_ip'>Allow IP</button>
</span>
</div>
</form>
";
}else if($ref=="setting"){
$set=mysql_fetch_array(mysql_query("select * from setting"));
?>
<div class='box box-primary'>
<div class="box-header">
    <h3 class="box-title"><li class='fa fa-wrench'></li> <small>PENGATURAN SISTEM</small></h3>
</div>
<div class='box-body'>
<form role='form' method='post'>
    <div class="form-group">
        <label>DENDA</label>
        <div class='form-group input-group'>
            <span class='input-group-addon'><strong>Rp.</strong></span>
            <input type='text' class='form-control text-bold' name='denda' value='<?php echo $set[1]?>'>
        </div>    
    </div>
    <div class="form-group">
        <label>MAKSIMAL PINJAMAN</label>
        <div class='form-group input-group'>
            <input type='text' class='form-control text-bold' name='batas_buku' value='<?php echo $set[2]?>'>
            <span class='input-group-addon'><strong>Buku</strong></span>
        </div>    
    </div>
    <div class="form-group">
        <label>BATAS PINJAMAN</label>
        <div class='form-group input-group'>
            <input type='text' class='form-control text-bold' name='batas_pinjam' value='<?php echo $set[3]?>'>
            <span class='input-group-addon'><strong>Hari</strong></span>
        </div>    
    </div>
    <div class="form-group">
        <label>SEMUA IP</label>
            <div class="radio">
                <?php if($set[4]==1){
                    echo"<label>
                    <input type='radio' name='ip' value='1' checked>Allow.
                </label>
                <label>
                    <input type='radio' name='ip' value='0'>Deny.
                </label>";}else{
                echo"<label>
                    <input type='radio' name='ip' value='1'>Allow.
                </label>
                <label>
                    <input type='radio' name='ip' value='0'  checked>Deny.
                </label>
                    ";}?>
        </div></div>
    </div><div class="box-footer"><button type="submit" name="update_set" class="btn btn-primary">Simpan</button></div>
</form>                         
</div><?php
}else if($ref=="personalize"){
?><div class='box box-success'>
<div class="box-header">
    <h3 class="box-title"><li class="fa fa-desktop"></li> <small>TAMPILAN</small></h3>
</div>
<div class="box-body">
<form role="form" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label>PROFILE</label>
        <div class='form-group input-group'>
            <input type='file' name='file'>
        </div>    
    </div>
    <div class="form-group">
        <label>TEMA</label>
            <select class="form-control text-bold" name="tema">
                <option value="<?php echo $user[3]?>"><?php echo $user[3]?></option>
                <option>----------</option>
                <option value="blue">blue</option>
                <option value="yellow">yellow</option>
                <option value="purple">purple</option>
                <option value="green">green</option>
                <option value="red">red</option>
                <option value="black">black</option>
            </select>    
    </div>
    <div class="form-group">
         <label>LAYOUT</label>
            <div class="radio">
                <?php if($user[4]=="fixed"){
                    echo"<label>
                    <input type='radio' name='layout' value='fixed' checked>Fixed.
                </label>
                <label>
                    <input type='radio' name='layout' value=''>Standar.
                </label>";}else{
                echo"<label>
                    <input type='radio' name='layout' value='fixed'>Fixed.
                </label>
                <label>
                    <input type='radio' name='layout' value=''  checked>Standar.
                </label>
                    ";}?>
        </div>      
    </div>
    </div><div class="box-footer"><button type="submit" name="tampilan" class="btn btn-primary">Simpan</button></div>
</form>                         
</div><?php
}else if($ref=="import"){
?>
<div class="box box-primary">
<div class="box-heading">

</div>
<div class="box-body">

<div class="panel">
<div class="panel-heading">
Import Data Buku
</div>
<div class="panel-body">
<button class="btn btn-danger btn-xs btn-flat pull-right" data-toggle="modal" data-target="#myModal" type="button"><i class="fa fa-times fa-fw"></i> Hapus Master Data Buku</button>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header pangel-warning">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title" id="myModalLabel"><i class="fa fa-warning f-fw"></i> Peringatan</h4>
</div>
<div class="modal-body">
<p>Anda yakin ingin menghapus master data buku ?</p>
<em class="text-danger">Menghapus master data dapat menghilangkan semua data transaksi dan data buku !</em>
</div>
<div class="modal-footer"><form method="post">
<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
<button name="delete_master_buku" type="submit" class="btn btn-primary">Lanjutkan</button></form>
</div>
</div>
</div>
</div>
<!-- /.modal -->
<form enctype="multipart/form-data" method="post">
<table><tr><td><input type="file" name="excel" required /></td>
<td><button class="btn btn-sm btn-success" name="excel_buku" type="submit">import</button></td></tr></table>
</form>
</div>
</div>

<div class="panel panel">
<div class="panel-heading">Import Data Anggota
</div>
<div class="panel-body">
<button class="btn btn-danger btn-xs btn-flat pull-right" data-toggle="modal" data-target="#myModal2" type="button"><i class="fa fa-times fa-fw"></i> Hapus Master Data Anggota</button>
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header pangel-warning">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title" id="myModalLabel"><i class="fa fa-warning f-fw"></i> Peringatan</h4>
</div>
<div class="modal-body">
<p>Anda yakin ingin menghapus master data anngota ?</p>
<em class="text-danger">Menghapus master data dapat menghilangkan semua data transaksi dan anggota !</em>
</div>
<div class="modal-footer"><form method="post">
<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
<button name="delete_master_anggota" type="submit" class="btn btn-primary">Lanjutkan</button></form>
</div>
</div>
</div>
</div>
<!-- /.modal -->
<form enctype="multipart/form-data" method="post">
<table><tr><td><input type="file" name="excel" required /></td>
<td><button class="btn btn-sm btn-success" name="excel_anggota" type="submit">import</button></td></tr></table>
</form>
</div>
</div>
    
<span class="text-info"><small>&#9679; Import > file type only <em>.xls</em></small></span>

</div>
</div>                      
<?php
}else if($ref=="passed"){
if(date("m")=="06" || date("m")=="07"){?>
<div class="box box-warning">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table class="table table-bordered table-striped table-hover">
                    <thead>
                      <tr>
                        <th>NO</th>
                        <th>SISWA</th>
                        <th>BUKU</th>
                        <th>STATUS</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
$qtrans=mysql_query("select kelas.*, buku_kelas.*, trans.*, siswa.*, buku.* from kelas, buku_kelas, trans, siswa, buku where kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='pinjam' && siswa.kelas like 'XII%' || kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='hilang' && siswa.kelas like 'XII%'");
$no=0;
while($trans=mysql_fetch_array($qtrans)){
$no++;
if($trans['jk']=='L'){
$jk='Laki - laki';
}else{
$jk='Perempuan';
}if($trans[7]=='pinjam'){
$status="<label class='label bg-green'>pinjam</label>";
}else{
$status="<label class='label bg-red'>hilang</label>";
} 
echo "<tr class='text-center'>
<form method='post'>
<td>$no</td>
<td><input type='hidden' value='$trans[no_induk]' name='nama_siswa'>
<div class='tooltip-demo'>
<a href='#' data-toggle='modal' data-target='#s$trans[no_induk]'>";echo strtoupper($trans['nama_siswa']);echo"</a>
<div class='modal fade' id='s$trans[no_induk]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-primary'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Siswa</h4>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='25%' rowspan='6'><img src='foto/$trans[foto_siswa]' height='133' width='100'></td>
<td width='25%'>No Induk</td><td width='10%'>:</td><td><strong>$trans[no_induk]</strong></td></tr>
<tr><td>Nama</td><td>:</td><td>$trans[nama_siswa]</td></tr>
<tr><td>Kelas</td><td>:</td><td>$trans[nama_kelas]</td></tr>
<tr><td>Jenis Kelamin</td><td>:</td><td>$jk</td></tr>
<tr><td>TTL</td><td>:</td><td>$trans[ttl]</td></tr>
<tr><td>Alamat</td><td>:</td><td>$trans[alamat]</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
</td>
<td><input type='hidden' value='$trans[id]' name='id'><input type='hidden' value='$trans[kode]' name='kode'>
<div class='tooltip-demo'>
<a href='#' data-toggle='modal' data-target='#b$trans[kode]'>$trans[judul]<input type='hidden' value='$trans[judul]' name='judul'></a>
<div class='modal fade' id='b$trans[kode]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-primary'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Buku</h4>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='35%' rowspan='9'><img src='foto/$trans[foto_buku]' height='230' width='150'></td>
<td width='25%'>Kode Buku</td><td width='10%'>:</td><td><strong>$trans[kode]</strong></td></tr>
<tr><td>Judul</td><td>:</td><td>$trans[judul]</td></tr>
<tr><td>Pengarang</td><td>:</td><td>$trans[pengarang]</td></tr>
<tr><td>Penerbit</td><td>:</td><td>$trans[penerbit]</td></tr>
<tr><td>Tahun Terbit</td><td>:</td><td>$trans[thn_terbit]</td></tr>
<tr><td>Buku Kelas</td><td>:</td><td>$trans[kelasifikasi_buku]</td></tr>
<tr><td>Lokasi</td><td>:</td><td>$trans[lokasi]</td></tr>
<tr><td>Tanggal Input</td><td>:</td><td>$trans[tgl_input]</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
</td>
<td>$status</td>
</tr>
";
}?>
</tbody>
                  </table>
                
                    <div class="box-footer"><button type="submit" name="pass" onclick="return confirm('Anda yakin ingin menghapus kelas XII ?')" class="btn btn-primary">Lanjutkan</button></div>
              </div></form><!-- /.box --><?php
}else{
echo "<div class=\"box box-warning\">
    <div class=\"box-header\">
    <i class=\"fa fa-level-up\"></i><small class=\"text-muted\">PASSED KELAS XII</small>
    </div>
    <div class=\"box-body\"><h4 class=\"text-center text-muted\"><i class=\"fa fa-warning text-red\"></i> Menu ini aktif pada bulan juni & juli</h4><br><br></div>
</div>";
}}}?>

    
</div>
</div>
</section>