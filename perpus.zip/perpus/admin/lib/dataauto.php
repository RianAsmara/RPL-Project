<?php
echo "var KodeBuku = [";
$qkode=mysql_query("select kode from buku where status='1'");
while($tkode=mysql_fetch_array($qkode)){

echo "\"$tkode[0]\",";
}

?>
""];

<?php
echo "var NoInduk = [";
$qinduk=mysql_query("select no_induk from siswa");
while($tinduk=mysql_fetch_array($qinduk)){

echo "\"$tinduk[0]\",";
}

?>
""];