<section class="content-header">
          <h1>
              <i class="fa fa-search"></i><b><small> "<?php if(isset($_POST['cari'])){
echo $_POST['cari'];
}else{
echo "";}?>"</small></b>
    </h1>
        </section>
<section class="content">
<div class="row">
<div class="col-lg-12">
<div class="panel-body">
<?php 
if(isset($_POST['cari'])){
$cari=$_POST['cari'];
$set=mysql_fetch_array(mysql_query("select * from setting"));
$c1 =mysql_num_rows(mysql_query("select * from siswa where no_induk like '%$cari%' || nama_siswa like '%$cari%'"));
$c2 =mysql_num_rows(mysql_query("select * from buku where kode like '%$cari%' || judul like '%$cari%'"));
$c3 =mysql_num_rows(mysql_query("select * from trans where status='pinjam' && no_induk like '%$cari%' || status='pinjam' && kode like '%$cari%'"));

if($cari!="" && $c1>0 || $c2>0 || $c3>0){
if ($c1>=1){
?>
<h4><a class="text-info" href="anggota">./Anggota</a></h4>
<div class="table-responsive">
<table class="table table-bordered table-hover">
<tbody>
<?php
$qsiswa=mysql_query("select kelas.nama_kelas, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && siswa.no_induk like '%$cari%' || kelas.nama_kelas=siswa.kelas && siswa.nama_siswa like '%$cari%' limit 5");
while($siswa=mysql_fetch_array($qsiswa)){
if($siswa['jk']=='L'){
$jk='Laki - laki';
}else{
$jk='Perempuan';
}
echo "<tr class='text-center info'>
<form method='post' action='anggota'>
<td>$siswa[no_induk]<input type='hidden' value='$siswa[no_induk]' name='id'></td>
<td>"; echo strtoupper($siswa['nama_siswa']);echo "<input type='hidden' value='$siswa[nama_siswa]' name='nama_siswa'></td>
<td>$siswa[nama_kelas]</td>
<td>$siswa[jk]</td>        
<td>
<div class='tooltip-demo'>
<button type='button' class='btn btn-xs btn-flat bg-blue' data-toggle='modal' data-target='#s$siswa[no_induk]'><i class='fa fa-bars'></i></button>
<div class='modal fade' id='s$siswa[no_induk]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-primary'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h5 class='modal-title' id='myModalLabel'>DETAIL ANGGOTA</h5>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='25%' rowspan='6'><input type='hidden' value='$siswa[foto_siswa]' name='foto_siswa'><img src='foto/$siswa[foto_siswa]' height='151' width='120'></td>
<td width='25%'>No Induk</td><td width='10%'>:</td><td><strong>$siswa[no_induk]</strong></td></tr>
<tr><td>Nama</td><td>:</td><td>$siswa[nama_siswa]</td></tr>
<tr><td>Kelas</td><td>:</td><td>$siswa[nama_kelas]</td></tr>
<tr><td>Jenis Kelamin</td><td>:</td><td>$jk</td></tr>
<tr><td>TTL</td><td>:</td><td>$siswa[ttl]</td></tr>
<tr><td>Alamat</td><td>:</td><td>$siswa[alamat]</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
<button type='submit' name='update' class='btn btn-xs bg-olive btn-flat'><i class='fa fa-edit'></i></button>
<button type='submit' name='hapus' class='btn btn-xs bg-red btn-flat' onclick='return confirm(\"Anda yakin ingin menghapus $siswa[nama_siswa] ?\")'><i class='fa fa-trash-o'></i></button>
</div></td>
</form>
</tr>
";
}?>
</tbody>
</table>
</div>
<?php } 

if ($c2>=1){
?>
<h4><a class="text-success" href="buku">./Buku</a></h4>
<div class="table-responsive">
<table class="table table-bordered table-hover">
<tbody>
<?php
$qbuku=mysql_query("select buku_kelas.kelasifikasi_buku, buku.* from buku_kelas, buku where buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && buku.status=0 && buku.kode like '%$cari%' || buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && buku.status=1 && buku.kode like '%$cari%' || buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && buku.status=0 && buku.judul like '%$cari%' || buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && buku.status=1 && buku.judul like '%$cari%' limit 5"); 
while($buku=mysql_fetch_array($qbuku)){
if($buku['status']=='1'){
$status="<label class='label bg-primary'>Tersedia</label>";
}else{
$status="<label class='label bg-red'>Tidak ada</label>";
}
echo "<tr class='text-center success'>
<form method='post' action='buku'>
<td>$buku[kode]<input type='hidden' value='$buku[kode]' name='kd_buku'></td>
<td>$buku[judul]<input type='hidden' value='$buku[judul]' name='judul'></td>
<td>$buku[pengarang]</td>
<td>$buku[thn_terbit]</td>
<td>$status<input type='hidden' value='$buku[foto_buku]' name='foto_buku'></td>            
<td>
<div class='tooltip-demo'>
<button type='button' class='btn btn-xs btn-flat bg-blue' data-toggle='modal' data-target='#$buku[kode]'><i class='fa fa-bars'></i></button>
<div class='modal fade' id='$buku[kode]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-olive'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Buku</h4>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='35%' rowspan='9'><img src='foto/$buku[foto_buku]' height='230' width='150'></td>
<td width='25%'>Kode Buku</td><td width='10%'>:</td><td><strong>$buku[kode]</strong></td></tr>
<tr><td>Judul</td><td>:</td><td>$buku[judul]</td></tr>
<tr><td>Pengarang</td><td>:</td><td>$buku[pengarang]</td></tr>
<tr><td>Penerbit</td><td>:</td><td>$buku[penerbit]</td></tr>
<tr><td>Tahun Terbit</td><td>:</td><td>$buku[thn_terbit]</td></tr>
<tr><td>Buku Kelas</td><td>:</td><td>$buku[kelasifikasi_buku]</td></tr>
<tr><td>Lokasi</td><td>:</td><td>$buku[lokasi]</td></tr>
<tr><td>Tanggal Input</td><td>:</td><td>$buku[tgl_input]</td></tr>
<tr><td>Status</td><td>:</td><td>$status</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
<button type='submit' name='ubah' class='btn btn-xs bg-olive btn-flat'><i class='fa fa-edit'></i></button>
<button type='submit' name='hapus' class='btn btn-xs bg-red btn-flat' onclick='return confirm(\"Anda yakin ingin menghapus buku $buku[judul]  ?\")'><i class='fa fa-trash-o'></i></button>
</div></td>
</form>
</tr>";}  
?>
</tbody>
</table>
</div>
<?php }
if ($c3>=1){
?>
<h4><a class="text-primary" href="transaksi">./Transaksi</a></h4>
<div class="table-responsive">
<table class="table table-bordered table-hover">
<tbody>
<?php
$qtrans=mysql_query("select kelas.nama_kelas, buku_kelas.kelasifikasi_buku, trans.*, siswa.*, buku.* from kelas, buku_kelas, trans, siswa, buku where kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='pinjam' && trans.kode like '%$cari%' || kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='pinjam' && trans.no_induk like '%$cari%' order by tgl_kembali limit 3");
$no=0;
while($trans=mysql_fetch_array($qtrans)){
$no++;
$sekarang = date ("d-m-Y");
$p= explode ("-", $trans['tgl_kembali']);
$d = $p[0];
$m = $p[1];
$y = $p[2];
$p2= explode ("-", $sekarang); 
$d2 = $p2[0];
$m2 = $p2[1];
$y2 = $p2[2];
$date1 = gregoriantojd($m, $d, $y);
$date2 = gregoriantojd($m2, $d2, $y2);
$selisih=$date2-$date1;
if($selisih>=1){
$telat="<a class='text-danger'>$selisih hari</a>";
}else{
$telat="0 hari";
}
if ($date2>$date1){
$a = $selisih*$set[1];
$denda = "<strong class='text-danger'>Rp.$a</strong>";
$b = "danger";
}
else {
$denda = "-";
$b = "";
}
if($trans['jk']=='L'){
$jk='Laki - laki';
}else{
$jk='Perempuan';
}

echo "<tr class='text-center $b'>
<form method='post' action='pinjaman'>
<td>$no</td>
<td><input type='hidden' value='$trans[id]' name='id'><input type='hidden' value='$trans[kode]' name='kode'>
<div class='tooltip-demo'>
<a href='#' data-toggle='modal' data-target='#b$trans[kode]'>$trans[judul]<input type='hidden' value='$trans[judul]' name='judul'></a>
<div class='modal fade' id='b$trans[kode]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Buku</h4>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='35%' rowspan='9'><img src='foto/$trans[foto_buku]' height='230' width='150'></td>
<td width='25%'>Kode Buku</td><td width='10%'>:</td><td><strong>$trans[kode]</strong></td></tr>
<tr><td>Judul</td><td>:</td><td>$trans[judul]</td></tr>
<tr><td>Pengarang</td><td>:</td><td>$trans[pengarang]</td></tr>
<tr><td>Penerbit</td><td>:</td><td>$trans[penerbit]</td></tr>
<tr><td>Tahun Terbit</td><td>:</td><td>$trans[thn_terbit]</td></tr>
<tr><td>Buku Kelas</td><td>:</td><td>$trans[kelasifikasi_buku]</td></tr>
<tr><td>Lokasi</td><td>:</td><td>$trans[lokasi]</td></tr>
<tr><td>Tanggal Input</td><td>:</td><td>$trans[tgl_input]</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
</td>

<td><input type='hidden' value='$trans[no_induk]' name='nama_siswa'>
<div class='tooltip-demo'>
<a href='#' data-toggle='modal' data-target='#s$trans[no_induk]'>$trans[nama_siswa]</a>
<div class='modal fade' id='s$trans[no_induk]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Siswa</h4>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='25%' rowspan='6'><img src='foto/$trans[foto_siswa]' height='133' width='100'></td>
<td width='25%'>No Induk</td><td width='10%'>:</td><td><strong>$trans[no_induk]</strong></td></tr>
<tr><td>Nama</td><td>:</td><td>$trans[nama_siswa]</td></tr>
<tr><td>Kelas</td><td>:</td><td>$trans[nama_kelas]</td></tr>
<tr><td>Jenis Kelamin</td><td>:</td><td>$jk</td></tr>
<tr><td>TTL</td><td>:</td><td>$trans[ttl]</td></tr>
<tr><td>Alamat</td><td>:</td><td>$trans[alamat]</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
</td>

<td><em class='text-success'>$trans[tgl_kembali]</em></td>
<td><strong class='text-danger'>$denda</strong></td>

<td>
<div class='tooltip-demo'>
<a class='btn btn-xs bg-blue btn-flat' title='Detail' data-toggle='modal' data-target='#t$trans[id]'><i class='fa fa-bars'></i></a>
<div class='modal fade' id='t$trans[id]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Transaksi</h4>
</div>
<div class='modal-body'>
<table width='100%' height='200' class='text-left'>
<tr><td width='25%'>Buku</td><td width='10%'>:</td><td>$trans[judul]</td></tr>
<tr><td>Siswa</td><td>:</td><td>$trans[nama_siswa]</td></tr>
<tr><td>Tgl Pinjam</td><td>:</td><td><em class='text-success'>$trans[tgl_pinjam]</em></td></tr>
<tr><td>Tgl Kembali</td><td>:</td><td><em class='text-success'>$trans[tgl_kembali]
<input type='hidden' value='$trans[tgl_kembali]' name='tgl_kembali'></em></td></tr>
<tr><td>Telat</td><td>:</td><td>$telat</td></tr>
<tr><td>Denda</td><td>:</td><td>$denda</td></tr>
<tr><td>Status</td><td>:</td><td><font class='text-danger'>Pinjam</font></td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
<button type='submit' title='Perpanjang' name='perpanjang' class='btn btn-xs btn-info btn-flat' onclick='return confirm(\"Anda yakin ingin perpanjang buku $trans[judul] ?\")'><i class='fa fa-upload'></i></button>
<button title='Kembali' type='submit' name='kembali' class='btn btn-xs btn-flat  btn-primary' onclick='return confirm(\"Anda yakin ingin mengembalikan buku $trans[judul] ?\")'><i class='fa fa-check'></i></button>
<button title='Hilang' type='submit' name='hilang' class='btn btn-xs btn-danger  btn-flat' onclick='return confirm(\"Anda yakin buku $trans[judul] hilang ?\")'><i class='fa fa-times'></i></button>
</td>
</form>
</tr>
";
}?>
</tbody>
</table>
</div>
<?php }}else{
echo "
 <div class=\"error-page\">
            <h2 class=\"headline text-muted\"> 404</h2>
            <div class=\"error-content\">
              <h3><i class=\"fa fa-warning text-muted\"></i> Oops! Data tidak temukan.</h3>
              <p>
                kami tidak dapat menemukan apa yang anda cari,<br> mungkin ada bisa ulangi dengan keyword yang lain.
              </p>
              <form class='search-form' method=\"post\" action=\"cari\">
                <div class='input-group'>
                  <input type=\"text\" name=\"cari\" class='form-control' placeholder=\"Cari...\" autofocus/>
                  <div class=\"input-group-btn\">
                    <button type=\"submit\" name=\"submit\" class=\"btn btn-primary btn-flat\"><i class=\"fa fa-search\"></i></button>
                  </div>
                </div><!-- /.input-group -->
              </form>
            </div><!-- /.error-content -->
          </div><!-- /.error-page -->
";	
	}}else{
echo "<div class=\"error-page\">
            <h2 class=\"headline text-muted\"> 404</h2>
            <div class=\"error-content\">
              <h3><i class=\"fa fa-warning text-muted\"></i> Oops! Data tidak temukan.</h3>
              <p>
                kami tidak dapat menemukan apa yang anda cari,<br> mungkin ada bisa ulangi dengan keyword yang lain.
              </p>
              <form class='search-form' method=\"post\" action=\"cari\">
                <div class='input-group'>
                  <input type=\"text\" name=\"cari\" class='form-control' placeholder=\"Cari...\" autofocus/>
                  <div class=\"input-group-btn\">
                    <button type=\"submit\" name=\"submit\" class=\"btn btn-primary btn-flat\"><i class=\"fa fa-search\"></i></button>
                  </div>
                </div><!-- /.input-group -->
              </form>
            </div><!-- /.error-content -->
          </div><!-- /.error-page -->";} ?>                                      
</div>
</div>
</div>
</section>
