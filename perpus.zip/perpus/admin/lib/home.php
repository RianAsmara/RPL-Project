<section class="content-header">
<?php
$namaHari = array("Ahad", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu","Minggu");
$namaBulan = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
$today = date('l, F j, Y');
$sekarang = $namaHari[date('N')] . ", " . date('j') . " " . $namaBulan[(date('n')-1)] . " " . date('Y');
?>
          <h1>
            <?php echo $namaHari[date('N')]?>
              <small><?php echo date('j')." ".$namaBulan[(date('n')-1)] ?>  <b> <?php echo date('Y')?></b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>
        <section class="content">
          <div class="row">
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                  <h3><?php echo mysql_num_rows(mysql_query("select * from siswa")) ?></h3>
                  <p>Semua Anggota</p>
                </div>
                <div class="icon">
                  <i class="fa fa-user"></i>
                </div>
                <a href="anggota" class="small-box-footer">Lihat semua <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3><?php echo mysql_num_rows(mysql_query("select * from buku where status='1' || status='0'"))?></h3>
                  <p>Data Buku</p>
                </div>
                <div class="icon">
                  <i class="fa fa-book"></i>
                </div>
                <a href="buku" class="small-box-footer">Lihat semua <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <h3><?php echo mysql_num_rows(mysql_query("select * from trans where status='pinjam'")) ?></h3>
                  <p>Transaksi</p>
                </div>
                <div class="icon">
                  <i class="fa fa-refresh"></i>
                </div>
                <a href="pinjaman" class="small-box-footer">Lihat semua <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                  <h3><?php echo mysql_num_rows(mysql_query("select * from buku where status='-1' || status='-2'"))?></h3>
                  <p>Buku Hilang</p>
                </div>
                <div class="icon">
                  <i class="fa fa-times"></i>
                </div>
                <a href="buku_hilang" class="small-box-footer">Lihat semua <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
          </div><!-- /.row -->

          <div class="row">
              
             <!-- /.nav-tabs-custom -->
              
            <div class="col-md-8">
               <div class="nav-tabs-custom">
                <ul class="nav nav-tabs pull-right">
                  <li class="active"><a href="#morris-bar-chart" data-toggle="tab">Angoota</a></li>
                  <li><a href="#areaChart" data-toggle="tab">Transaksi</a></li>
                <li class="pull-left header"><i class="fa fa-bar-chart-o"></i> Grafik</li>
                </ul>
                   <div class="box-body">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="chart-responsive">
                        <div class="tab-content no-padding">
                    <div class="chart tab-pane active" id="morris-bar-chart"></div>
                    <canvas class="chart tab-pane" id="areaChart" height="400px"></canvas>   
                </div>
                      </div><!-- /.chart-responsive -->
                    </div><!-- /.col -->
                  </div><!-- /.row -->
                </div>
                </div>
                   
         
              </div>  
            <div class='col-md-4'>
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title"><i class="fa fa-refresh"></i> Detail Transaksi</h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div class="row">
                    <div class="col-md-8">
                      <div class="chart-responsive">
                        <canvas id="pieChart" height="150"></canvas>
                      </div><!-- ./chart-responsive -->
                    </div><!-- /.col -->
                    <div class="col-md-4">
                      <ul class="chart-legend clearfix">
                          <li><i class="fa fa-circle-o text-red"></i> <small>TAV</small></li>
                          <li><i class="fa fa-circle-o text-green"></i> <small>TGB</small></li>
                          <li><i class="fa fa-circle-o text-yellow"></i> <small>TKK</small></li>
                          <li><i class="fa fa-circle-o text-aqua"></i> <small>TKR</small></li>
                          <li><i class="fa fa-circle-o text-light-blue"></i> <small>TSM</small></li>
                          <li><i class="fa fa-circle-o text-purple"></i> <small>RPL</small></li>
                          <li><i class="fa fa-circle-o text-maroon"></i> <small>TIL</small></li>
                          <li><i class="fa fa-circle-o text-muted"></i> <small>TP</small></li>
                      </ul>
                    </div><!-- /.col -->
                  </div><!-- /.row -->
                </div><!-- /.box-body -->
                <div class="box-footer no-padding">
                  <ul class="nav nav-pills nav-stacked">
                      <?php $x=mysql_num_rows(mysql_query("select kelas.*, siswa.*, trans.no_induk from siswa, kelas, trans where trans.no_induk=siswa.no_induk && kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'X %'"));$xi=mysql_num_rows(mysql_query("select kelas.*, siswa.*, trans.no_induk from siswa, kelas, trans where trans.no_induk=siswa.no_induk && kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XI %'"));$xii=mysql_num_rows(mysql_query("select kelas.*, siswa.*, trans.no_induk from siswa, kelas, trans where trans.no_induk=siswa.no_induk && kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XII%'"));
$total=$x+$xi+$xii;
?>
                      <li><a href="#"><b>Kelas</b> XII <span class="pull-right text-blue"> <?php echo $xii?></span></a></li>
                    <li><a href="#"><b>Kelas</b> XI <span class="pull-right text-blue"> <?php echo $xi?></span></a></li>
                    <li><a href="#"><b>Kelas</b> X <span class="pull-right text-blue"> <?php echo $x?></span></a></li>
                      <div class="box-footer bg-maroon"><b>TOTAL <span class="pull-right"> <?php echo $total?></span></b></div>
                  </ul>
                </div><!-- /.footer -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section>
<?php include 'lib/data.php' ?>
<script src="dist/js/pages/dashboard.js" type="text/javascript"></script>