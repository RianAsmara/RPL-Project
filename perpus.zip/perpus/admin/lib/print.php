<section class="content-header">
          <h1>
              <a href="print.html" target="_blank"><i class="fa fa-print fa-fw"></i><small><b>PRINT</b></small></a>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Print</li>
          </ol>
        </section>
<section class="content"> 
<div class="row">
          <div class="col-md-12">
            <h2 class="page-header">
                LAPORAN PERPUSTAKAAN
              <small class="pull-right"><?php echo date("d/m/Y")?></small>
            </h2>
          </div><!-- /.col -->
        </div>
        <!-- info row -->

        <!-- Table row -->
        <div class="row">
          <div class="col-xs-12 table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>NO</th>
                  <th>NAMA</th>
                  <th>KELAS</th>
                  <th>STATUS</th>
                  <th>BUKU</th>
                </tr>
              </thead>
              <tbody>
<?php
$qtrans=mysql_query("select kelas.*, buku_kelas.*, trans.*, siswa.*, buku.* from kelas, buku_kelas, trans, siswa, buku where kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='pinjam' || kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='hilang' order by siswa.kelas");
$no=0;
while($trans=mysql_fetch_array($qtrans)){
$no++;
if($trans[7]=='pinjam'){
$status="Pinjam";
}else{
$status="Hilang";
}?> 
<tr class='text-center'>
<form method='post'>
<td><?php echo $no?></td>
<td><?php echo strtoupper($trans['nama_siswa'])?></td>
<td><?php echo $trans['kelas']?></td>
<td><?php echo $status ?></td>
<td><?php echo $trans['judul'];
?>
</td>
</tr>
<?php }?>
              </tbody>
            </table>
          </div><!-- /.col -->
        </div><!-- /.row -->
</section>