<?php
session_destroy();
?>
<script>document.location = "login"</script>