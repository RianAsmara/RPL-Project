<?php 
$xrpl=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'X RPL%'"));
$xirpl=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XI RPL%'"));
$xiirpl=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XII RPL%'"));

$xtav=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'X TAV%'"));
$xitav=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XI TAV%'"));
$xiitav=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XII TAV%'"));

$xtgb=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'X TGB%'"));
$xitgb=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XI TGB%'"));
$xiitgb=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XII TGB%'"));
$xtkk=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'X TKK%'"));
$xitkk=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XI TKK%'"));
$xiitkk=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XII TKK%'"));

$xtsm=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'X TSM%'"));
$xitsm=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XI TSM%'"));
$xiitsm=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XII TSM%'"));

$xtil=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'X TIL%'"));
$xitil=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XI TIL%'"));
$xiitil=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XII TIL%'"));

$xtp=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'X TP%'"));
$xitp=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XI TP%'"));
$xiitp=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XII TP%'"));

$xtkr=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'X TKR%'"));
$xitkr=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XI TKR%'"));
$xiitkr=mysql_num_rows(mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like 'XII TKR%'"));

$tav=mysql_num_rows(mysql_query("select kelas.*, siswa.*, trans.no_induk from siswa, kelas, trans where trans.no_induk=siswa.no_induk && kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like '%TAV%'"));
$tgb=mysql_num_rows(mysql_query("select kelas.*, siswa.*, trans.no_induk from siswa, kelas, trans where trans.no_induk=siswa.no_induk && kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like '%TGB%'"));
$tkk=mysql_num_rows(mysql_query("select kelas.*, siswa.*, trans.no_induk from siswa, kelas, trans where trans.no_induk=siswa.no_induk && kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like '%TKK%'"));
$tkr=mysql_num_rows(mysql_query("select kelas.*, siswa.*, trans.no_induk from siswa, kelas, trans where trans.no_induk=siswa.no_induk && kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like '%TKR%'"));
$tsm=mysql_num_rows(mysql_query("select kelas.*, siswa.*, trans.no_induk from siswa, kelas, trans where trans.no_induk=siswa.no_induk && kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like '%TSM%'"));
$rpl=mysql_num_rows(mysql_query("select kelas.*, siswa.*, trans.no_induk from siswa, kelas, trans where trans.no_induk=siswa.no_induk && kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like '%RPL%'"));
$til=mysql_num_rows(mysql_query("select kelas.*, siswa.*, trans.no_induk from siswa, kelas, trans where trans.no_induk=siswa.no_induk && kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like '%TIL%'"));
$tp=mysql_num_rows(mysql_query("select kelas.*, siswa.*, trans.no_induk from siswa, kelas, trans where trans.no_induk=siswa.no_induk && kelas.nama_kelas=siswa.kelas && kelas.nama_kelas like '%TP%'"));
$year=date("Y");
$year1=$year-1;
$jan=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-01-$year'"));
$feb=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-02-$year'"));
$mar=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-03-$year'"));
$apr=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-04-$year'"));
$mei=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-05-$year'"));
$jun=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-06-$year'"));
$jul=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-07-$year'"));
$agu=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-08-$year'"));
$sep=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-09-$year'"));
$okt=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-10-$year'"));
$nov=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-11-$year'"));
$des=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-12-$year'"));
$jan1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-01-$year1'"));
$feb1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-02-$year1'"));
$mar1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-03-$year1'"));
$apr1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-04-$year1'"));
$mei1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-05-$year1'"));
$jun1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-06-$year1'"));
$jul1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-07-$year1'"));
$agu1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-08-$year1'"));
$sep1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-09-$year1'"));
$okt1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-10-$year1'"));
$nov1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-11-$year1'"));
$des1=mysql_num_rows(mysql_query("select * from trans where tgl_pinjam like '%-12-$year1'"));
?>
    <script>
    $(function() {

   Morris.Bar({
        element: 'morris-bar-chart',
        data: [{
            y : 'Kelas X',
            a : <?php echo $xrpl?>,
            b : <?php echo $xtav?>,
			c : <?php echo $xtgb?>,
			d : <?php echo $xtkk?>,
            e : <?php echo $xtsm?>,
			f : <?php echo $xtkr?>,
            g : <?php echo $xtil?>,
            h : <?php echo $xtp?>
        }, { y : 'Kelas XI',
            a : <?php echo $xirpl?>,
            b : <?php echo $xitav?>,
			c : <?php echo $xitgb?>,
			d : <?php echo $xitkk?>,
            e : <?php echo $xitsm?>,
			f : <?php echo $xitkr?>,
            g : <?php echo $xitil?>,
            h : <?php echo $xitp?>
        }, { y : 'Kelas XII',
            a : <?php echo $xiirpl?>,
            b : <?php echo $xiitav?>,
			c : <?php echo $xiitgb?>,
			d : <?php echo $xiitkk?>,
            e : <?php echo $xiitsm?>,
			f : <?php echo $xiitkr?>,
            g : <?php echo $xiitil?>,
            h : <?php echo $xiitp?>
        }],
        xkey: 'y',
        ykeys: ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'],
        labels: ['RPL', 'TAV', 'TGB', 'TKK', 'TSM', 'TKR', 'TIL', 'TP'],
        hideHover: 'auto',
        resize: true
    });
});
        
var areaChartData = {
          labels: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul","agu","sep","okt","nov","des"],
          datasets: [
            {
            fillColor: "rgb(210, 214, 222)",
            strokeColor: "rgb(210, 214, 222)",
            pointColor: "rgb(210, 214, 222)",
            pointStrokeColor: "#c1c7d1",
            pointHighlightFill: "#fff",
            pointHighlightStroke: "rgb(220,220,220)",
            data: [<?php echo "$jan1,$feb1,$mar1,$apr1,$mei1,$jun1,$jul1,$agu1,$sep1,$okt1,$nov1,$des1"?>]
      },{
            fillColor: "rgba(60,141,188,0.9)",
            strokeColor: "rgba(60,141,188,0.8)",
            pointColor: "#3b8bba",
            pointStrokeColor: "rgba(60,141,188,1)",
            pointHighlightFill: "#fff",
            pointHighlightStroke: "rgba(60,141,188,1)",
            data: [<?php echo "$jan,$feb,$mar,$apr,$mei,$jun,$jul,$agu,$sep,$okt,$nov,$des"?>]
            }
          ]
        };
var PieData = [
    {
      value: <?php echo $tav?>,
      color: "#f56954",
      highlight: "#f56954",
      label: "TAV"
    },
    {
      value: <?php echo $tgb?>,
      color: "#00a65a",
      highlight: "#00a65a",
      label: "TGB"
    },
    {
      value: <?php echo $tkk?>,
      color: "#f39c12",
      highlight: "#f39c12",
      label: "TKK"
    },
    {
      value: <?php echo $tkr?>,
      color: "#00c0ef",
      highlight: "#00c0ef",
      label: "TKR"
    },
    {
      value: <?php echo $tsm?>,
      color: "#3c8dbc",
      highlight: "#3c8dbc",
      label: "TSM"
    },
    {
      value: <?php echo $rpl?>,
      color: "#605ca8",
      highlight: "#605ca8",
      label: "RPL"
    },{
      value: <?php echo $til?>,
      color: "#d81b60",
      highlight: "#d81b60",
      label: "TIL"
    },{
      value: <?php echo $tp?>,
      color: "#d2d6de",
      highlight: "#d2d6de",
      label: "TP"
    }
  ];
    </script>