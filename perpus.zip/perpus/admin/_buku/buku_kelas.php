<section class="content-header">
          <h1>
              <i class="fa fa-book fa-fw"></i><small><b>KELASIFIKASI BUKU</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="buku">Buku</a></li>
            <li class="active">Kelasifikasi buku</li>
          </ol>
        </section>
<section class="content">
<?php
if(isset($_POST['tambah'])){
$bukukelas=$_POST['buku_kelas'];
$z=mysql_query("insert into buku_kelas values('$bukukelas')");
if($z){ 
    echo "<div class='alert alert-success alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Kelasifikasi buku <label><em>$bukukelas</em></label> berhasil ditambah
</div>";
}else{   
    echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div>";
}}

if(isset($_POST['hapus'])){
$bukukelas=$_POST['buku_kelas'];
$z=mysql_query("delete from buku_kelas where kelasifikasi_buku='$bukukelas'");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Kelasifikasi buku <label><em>$bukukelas</em></label> berhasil dihapus
</div>";
}else{   
    echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div>";
}} ?>

<div class="row">
<div class="col-md-3">
<div class="box box-warning">
<div class="box-body">
<form method="post">
<label>Tambah</label>
<div class="form-group input-group">
<input type="text" name="buku_kelas" class="form-control" placeholder='Nama kelasifikasi' required>
<span class="input-group-btn">
<button class="btn btn-primary" name="tambah" type="submit"><strong>+</strong>
</button>
</span>
</div>
</form>
</div>
</div>
</div>
    
    <div class="col-md-9">
<div class="box box-warning">
<div class="box-header">
</div>
<div class="box-body">
    <table id="Dtable" class="table table-bordered table-striped table-hover text-center">
        <thead>
          <tr>
            <th>NO</th>
            <th>JUDUL</th>
            <th>KELASIFIKASI</th>
            <th>ACTION</th>
          </tr>
        </thead>
        <tbody>
            <?php 
$qkelasifikasi=mysql_query("select * from buku_kelas");
$no=0;
while($kelasifikasi=mysql_fetch_array($qkelasifikasi)){
    $count=mysql_num_rows(mysql_query("select kelasifikasi_buku from buku where kelasifikasi_buku='$kelasifikasi[kelasifikasi_buku]'"));
    if($count==0){
        $data="0";
    }else{$data="<label class='label bg-green'>$count</label>";}
$no++;
echo"<tr>
<form method='post'>
<td width='50'>$no</td>
<td>$kelasifikasi[kelasifikasi_buku]<input type='hidden' name='buku_kelas' value='$kelasifikasi[kelasifikasi_buku]'></td>
<td>$data</td>
<td>
<button type='submit' name='hapus' class='btn btn-xs btn-danger btn-flat' onclick='return confirm(\"Anda yakin ingin menghapus kelas $kelasifikasi[kelasifikasi_buku]  ?\")'><i class='fa fa-trash-o'></i></button>
</td>
</form>
</tr>";}?>
        </tbody>
    </table>
</div>
</div>
</div>
    
</div>
</section>