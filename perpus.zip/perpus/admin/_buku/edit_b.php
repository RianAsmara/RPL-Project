<?php
if(isset($_POST['hapus'])){
$id=$_POST['kd_buku'];
$judul=$_POST['judul'];
$foto=$_POST['foto_buku'];
if($foto!=""){unlink("../foto/$foto");}
$z=mysql_query("delete from buku where kode='$id'");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
<p>Buku \"$judul\" berhasil dihapus</p>
</div>";
}else{   
    echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div>";
}}

if(isset($_POST['edit'])){
$kode=$_POST['kd_buku'];
$buku=mysql_fetch_array(mysql_query("select * from buku where kode='$kode'"));
    $a=$_POST['kd_buku'];
    $b=strtoupper(mysql_real_escape_string($_POST['judul']));
    $c=$_POST['pengarang'];
    $d=$_POST['penerbit'];
    $e=$_POST['tahun_terbit'];
    $f=$_POST['kelasifikasi'];
	$g=$_POST['lokasi'];
	$h=date("d-m-Y");
	$file=$_FILES['file']['name'];
		    
if($file==""){
$z=mysql_query("update buku set judul='$b', pengarang='$c', penerbit='$d', thn_terbit='$e', kelasifikasi_buku='$f', lokasi='$g' where kode='$a'");	
}else{
if($buku[7]!=""){unlink("../foto/$buku[7]");}
$upload = "../foto/$a." . basename($_FILES['file']['name']);
$simpan = "$a." . basename($_FILES['file']['name']);   
move_uploaded_file($_FILES['file']['tmp_name'], $upload);		
$z=mysql_query("update buku set judul='$b', pengarang='$c', penerbit='$d', thn_terbit='$e', kelasifikasi_buku='$f', lokasi='$g', foto_buku='$simpan' where kode='$a'");
}
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Buku  \"$b\"  berhasil di ubah.
</div>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div></h5>";
}}

if(isset($_POST['ubah'])){
$id=$_POST['kd_buku'];
$buku=mysql_fetch_array(mysql_query("select * from buku where kode='$id'"));
?>
<div class="row">
<form role="form" method="post" enctype="multipart/form-data" action="">
<div class="col-md-6">
<div class="box box-success">
<div class="box-header">
    <h3 class="box-title">UBAH <small>INFORMASI UMUM</small></h3>
    <div class="box-tools pull-right">
        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
    </div>
</div>
<div class="box-body">
    <div class="form-group">
        <label>KD. BUKU</label>
        <input type="text" class="form-control" value="<?php echo $buku['kode'] ?>" autocomplete="off" name="kd_buku" placeholder="ex. 98578" readonly required>
    </div>
    <div class="form-group">
        <label>JUDUL </label>
        <input type="text" class="form-control" value="<?php echo $buku['judul'] ?>" name="judul" autocomplete="off" placeholder="ex.  BAHASA INDONESIA" required>
    </div>
    <div class="form-group">
        <label>PENGARANG</label>
        <input type="text" class="form-control" value="<?php echo $buku['pengarang'] ?>" name="pengarang" autocomplete="off" placeholder="ex.  Adam ishak" required>
    </div>
    <div class="form-group">
        <label>PENERBIT</label>
        <input type="text" class="form-control" value="<?php echo $buku['penerbit'] ?>" name="penerbit" autocomplete="off" placeholder="ex.  Elangga" required>
    </div>
    <div class="form-group">
        <label>TAHUN TERBIT</label>
        <input type="text" class="form-control" value="<?php echo $buku['thn_terbit'] ?>" name="tahun_terbit" autocomplete="off" placeholder="ex.  2003" required>
    </div>
    <div class="form-group">
        <label>KELASIFIKASI</label>
        <select class="form-control  text-bold" name="kelasifikasi" required>
<?php
$qkelasifikasi=mysql_query("select * from buku_kelas");
while($kelasifikasi=mysql_fetch_array($qkelasifikasi)){
if($kelasifikasi['kelasifikasi_buku']==$buku['kelasifikasi_buku']){
$selected='selected';
} else {
$selected='';
}
echo"
<option value='$kelasifikasi[kelasifikasi_buku]' $selected>$kelasifikasi[kelasifikasi_buku]</option>
";}?>       
      </select>
    </div>                      
</div>
</div>
</div>
    
    <div class="col-md-6">
<div class="box box-success">
<div class="box-header">
    <h3 class="box-title">UBAH <small>INFORMASI TAMBAHAN</small></h3>
    <div class="box-tools pull-right">
        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
    </div>
</div>
<div class="box-body">
    <div class="form-group">
    <div class="col-xs-7">
      <label for="exampleInputFile">FOTO</label>
      <input type="file" name="file" id="preview_gambar">
      <p class="help-block">Gunakan foto Reolusi 3x4</p>
        </div>
    <div class="col-xs-5">
        <div class="box box-danger text-center">
            <div class="box-header"></div>
        <img src="foto/<?php echo $buku['foto_buku']?>" id="gambar_nodin" height="200" width="130"/>
            <div class="box-footer"> Preview </div>
<script>
    function bacaGambar(input) {
   if(input.files && input.files[0]){
      var reader = new FileReader();
      reader.onload = function (e) {
          $('#gambar_nodin').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
   }
}
</script>
        </div>
        </div>
    </div>
    <div class="form-group">
      <label>LOKASI</label>
      <textarea class="form-control" name="lokasi" rows="1" placeholder="ex. Rak 1, kiri (2)"><?php echo $buku['lokasi'] ?></textarea>
    </div>                             
</div>
    <div class="box-footer">
        <button type="submit" class="btn bg-olive" name="edit">Ubah</button>
        <button type="reset" class="btn btn-danger">Reset</button>
    </div>
</div>
</div>
</form>
</div>
<?php } ?>