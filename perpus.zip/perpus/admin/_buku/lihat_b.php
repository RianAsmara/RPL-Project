<section class="content-header">
          <h1>
              <a href="tambah_buku" title="Tambah Buku Baru"><i class="fa fa-book fa-fw"></i></a><small><b>DATA BUKU</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Buku</li>
          </ol>
        </section>
 <section class="content">
     <?php include ('_buku/edit_b.php')?>
     <div class="row">
            <div class="col-xs-12">
              <div class="box box-primary">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="Dtable" class="table table-bordered table-striped table-hover">
                    <thead>
                      <tr>
                        <th>KD</th>
                        <th>JUDUL</th>
                        <th>PENGARANG</th>
                        <th>KELAS</th>
                        <th>STATUS</th>
                        <th>ACTION</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
$qbuku=mysql_query("select buku_kelas.kelasifikasi_buku, buku.kode,buku.judul,buku.pengarang,buku.status,buku.foto_buku from buku_kelas, buku where buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && buku.status=0 || buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && buku.status=1 LIMIT 100");
while($buku=mysql_fetch_array($qbuku)){
if($buku['status']=='1'){
$status="<label class='label bg-primary'>Tersedia</label>";
}else{
$status="<label class='label bg-red'>Tidak ada</label>";
}
echo "<tr class='text-center'>
<form method='post'>
<td>$buku[kode]<input type='hidden' value='$buku[kode]' name='kd_buku'></td>
<td>$buku[judul]<input type='hidden' value='$buku[judul]' name='judul'></td>
<td>$buku[pengarang]</td>
<td>$buku[kelasifikasi_buku]</td>
<td>$status<input type='hidden' value='$buku[foto_buku]' name='foto_buku'></td>            
<td>
<button type='submit' name='ubah' class='btn btn-xs bg-olive btn-flat'><i class='fa fa-edit'></i></button>
<button type='submit' name='hapus' class='btn btn-xs bg-red btn-flat' onclick='return confirm(\"Anda yakin ingin menghapus buku $buku[judul]  ?\")'><i class='fa fa-trash-o'></i></button>
</div></td>
</form>
</tr>";}?>
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
     <div class="label label-primary">
    Data buku limit 100
</div>
        </section><!-- /.content -->