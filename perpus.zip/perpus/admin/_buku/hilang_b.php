<section class="content-header">
          <h1>
             <i class="fa fa-book fa-fw"></i><small><b>DAFTAR BUKU HILANG</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
              <li class="active"><a href="buku">Buku</a></li>
            <li class="active">Buku hilang</li>
          </ol>
        </section>
 <section class="content">
     <?php
if(isset($_POST['ganti'])){
$id=$_POST['id'];
$kode=$_POST['kode'];
$buku=$_POST['judul'];
$z=mysql_query("update trans set status='ganti' where id='$id'");
mysql_query("update buku set status='-2' where kode='$kode'");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Buku \"$buku\" telah di ganti
</div>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div></h5>";
}}

if(isset($_POST['kembali'])){
$id=$_POST['id'];
$kode=$_POST['kode'];
$buku=$_POST['judul'];
$z=mysql_query("update trans set status='kembali' where id='$id'");
mysql_query("update buku set status='1' where kode='$kode'");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Buku \"$buku\" telah di kembalikan.
</div>";
}else{   
    echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div>";
}}?>
<div class="row">
            <div class="col-xs-12">
              <div class="box box-danger">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="Dtable" class="table table-bordered table-striped table-hover">
                    <thead>
                      <tr>
                        <th>KODE</th>
                        <th>JUDUL</th>
                        <th>PENGARANG</th>
                        <th>STATUS</th>
                        <th>ACTION</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
$qbuku=mysql_query("select buku_kelas.*, trans.*, buku.* from buku_kelas, trans, buku where buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && buku.kode=trans.kode && buku.status='-1' && trans.status='hilang' || buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && buku.kode=trans.kode && buku.status='-2' && trans.status='ganti'");
while($buku=mysql_fetch_array($qbuku)){
if($buku['status']=='-2'){
$disable="disabled";$warna="";$status="<label class='label bg-green'>lunas</label>";
}else{ $status="<label class='label bg-red'>hilang</label>";$disable="";$warna="danger";}
echo "<tr class='text-center $warna'>
<form method='post'>
<td>$buku[kode]<input type='hidden' value='$buku[id]' name='id'><input type='hidden' value='$buku[kode]' name='kode'></td>
<td>$buku[judul]<input type='hidden' value='$buku[judul]' name='judul'></td>
<td>$buku[pengarang]</td>
<td>$status<input type='hidden' value='$buku[foto_buku]' name='foto_buku'></td>            
<td>
<div class='tooltip-demo'>
<button type='button' class='btn btn-flat btn-xs bg-blue' data-toggle='modal' data-target='#$buku[kode]'><i class='fa fa-bars'></i></button>
<div class='modal fade' id='$buku[kode]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-red'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Buku</h4>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='35%' rowspan='9'><img src='foto/$buku[foto_buku]' height='230' width='150'></td>
<td width='25%'>Kode Buku</td><td width='10%'>:</td><td><strong>$buku[kode]</strong></td></tr>
<tr><td>Judul</td><td>:</td><td>$buku[judul]</td></tr>
<tr><td>Pengarang</td><td>:</td><td>$buku[pengarang]</td></tr>
<tr><td>Penerbit</td><td>:</td><td>$buku[penerbit]</td></tr>
<tr><td>Tahun Terbit</td><td>:</td><td>$buku[thn_terbit]</td></tr>
<tr><td>Buku Kelas</td><td>:</td><td>$buku[kelasifikasi_buku]</td></tr>
<tr><td>Lokasi</td><td>:</td><td>$buku[lokasi]</td></tr>
<tr><td>Tanggal Input</td><td>:</td><td>$buku[tgl_input]</td></tr>
<tr><td>Status</td><td>:</td><td>$status</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
<button type='submit' name='ganti' title='Ganti Rugi' class='btn btn-xs bg-olive btn-flat' onclick='return confirm(\"Ganti rugi buku $buku[judul]  ?\")' $disable>Rp</button>
<button title='Kembali' type='submit' name='kembali' class='btn btn-xs btn-flat btn-primary' onclick='return confirm(\"Anda yakin buku $buku[judul] telah kembali ?\")'><i class='fa fa-check'></i></button>
</div></td>
</form>
</tr>";}  
?>
</tbody>
</table>
</div>
</div>                     
</div>
</div>
</section>