<section class="content-header">
          <h1>
              <a href="transaksi_kelas" title="Transaksi Kelas"><i class="fa fa-retweet fa-fw"></i></a><small><b>TRANSAKSI</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Transaksi</li>
          </ol>
        </section>
<section class="content">
<div class="row">
<div class="col-xs-12">
<?php 
if (isset($_POST['edit'])){
$id=$_POST['idtrans'];
$data=mysql_fetch_array(mysql_query("select * from trans2 where id='$id'"));
echo"
<form method=\"post\">
<div class=\"box box-success\">
        <div class=\"box-header\">
            <h3 class=\"box-title\">UBAH TRANSAKSI</h3>
            <div class=\"box-tools pull-right\">
        <button class=\"btn btn-box-tool\" data-widget=\"remove\"><i class=\"fa fa-times\"></i></button>
    </div>
        </div>
        <div class=\"box-body\">
            <div class=\"form-group\">
                <label>NAMA SISWA</label>
                <input type=\"hidden\" name=\"idtrans\" value=\"$data[0]\">
                <input type=\"text\" class=\"form-control\" name=\"nama_siswa\" value=\"$data[1]\">
            </div>
            <div class=\"form-group\">
                <label>KELAS</label>
                <input type=\"text\" class=\"form-control\" name=\"kelas\" value=\"$data[2]\">
            </div>
            <div class=\"form-group\">
                <label>JUDUL BUKU</label>
                <input type=\"text\" class=\"form-control\" name=\"judul_buku\" value=\"$data[3]\">
            </div>
            <div class=\"form-group\">
                <label>JUMLAH</label>
                <input type=\"text\" class=\"form-control\" name=\"jumlah\" value=\"$data[4]\">
            </div>
            <div class=\"box-footer\">
                <button type=\"submit\" class=\"btn bg-olive\" name=\"edit2\">Ubah</button>
                <button type=\"reset\" class=\"btn btn-danger\">Reset</button>
            </div>
        </div>
    </div>
    </form> 
";}
if(isset($_POST['kembali'])){
$idtrans=$_POST['idtrans'];
$kelas=$_POST['kelas'];
$z=mysql_query("update trans2 set status='0' where id='$idtrans'");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Berhasil mengambalikan buku</div>";
}}
if(isset($_POST['edit2'])){
$id=$_POST['idtrans'];
$nama_siswa=$_POST['nama_siswa'];
$kelas=$_POST['kelas'];
$judul_buku=$_POST['judul_buku'];
$jumlah=$_POST['jumlah'];
$kelas=$_POST['kelas'];
$z=mysql_query("update trans2 set nama_siswa='$nama_siswa',kelas='$kelas',judul_buku='$judul_buku',jumlah='$jumlah' where id='$id'");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Transaksi \"$kelas\" telah diubah</div>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div></h5>";
}}
?>
<div class="box box-primary">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="Dtable" class="table table-bordered table-striped table-hover">
                    <thead>
                      <tr>
                        <th>NO</th>
                        <th>NAMA</th>
                        <th>KELAS</th>
                        <th>BUKU</th>
                        <th>TGL.PINJAM</th>
                        <th>ACTION</th>
                        
                      </tr>
                    </thead>
                    <tbody>
<?php 
$qtrans=mysql_query("select * from trans2 where status='1' order by id");
$no=0;
while($trans=mysql_fetch_array($qtrans)){
$no++;
?><tr class="text-center">
<form method="post">
<td width="50"><?php echo $no?><input type="hidden" name="idtrans" value="<?php echo $trans['id']?>"></td>
<td><?php echo strtoupper($trans['nama_siswa'])?></td>
<td><?php echo strtoupper($trans['kelas'])?><input type="hidden" name="kelas" value="<?php echo $trans[kelas]?>"></td>
<td><?php echo strtoupper($trans['judul_buku'])?> <b class="text-primary">(<?php echo $trans['jumlah']?>)</b></td>
<td><?php echo $trans['tgl_pinjam']?></td>
<td>
<button type="submit" name="kembali" class="btn btn-xs btn-flat btn-primary" onclick="return confirm('Anda yakin ingin mengembalikan buku <?php echo $trans['judul_buku']?> ?')"><i class="fa fa-check"></i></button>
<button type="submit" name="edit" class="btn btn-xs btn-flat bg-olive"><i class="fa fa-edit"></i></button>
</td>
</form>
</tr><?php }?>
</tbody>
</table>
</div>                                      
</div>
</div>
</div>
</section>