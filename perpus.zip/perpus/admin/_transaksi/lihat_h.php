<section class="content-header">
          <h1>
              <a href="transaksi_anggota" title="Transaksi Baru"><i class="fa fa-retweet fa-fw"></i></a><small><b>TRANSAKSI</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Transaksi</li>
          </ol>
        </section>
<section class="content">     
 <div class="row">
            <div class="col-xs-12">
              <div class="box box-primary">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="Dtable" class="table table-bordered table-striped table-hover">
                    <thead>
                      <tr>
                        <th>NO</th>
                        <th>SISWA</th>
                        <th>BUKU</th>
                        <th>TGL.KEMBALI</th>
                        <th>STATUS</th>
                        <th>ACTION</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
$qtrans=mysql_query("select kelas.*, buku_kelas.*, trans.*, siswa.*, buku.* from kelas, buku_kelas, trans, siswa, buku where kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='kembali' order by id desc limit 100");
$no=0;
while($trans=mysql_fetch_array($qtrans)){
$no++;
if($trans['jk']=='L'){
$jk='Laki - laki';
}else{
$jk='Perempuan';
}

echo "<tr class='text-center'>
<form method='post'>
<td>$no</td>
<td>
<div class='tooltip-demo'>
<a href='#' data-toggle='modal' data-target='#b$trans[kode]'>$trans[judul]</a>
<div class='modal fade' id='b$trans[kode]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-primary'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Buku</h4>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='35%' rowspan='9'><img src='foto/$trans[foto_buku]' height='230' width='150'></td>
<td width='25%'>Kode Buku</td><td width='10%'>:</td><td><strong>$trans[kode]</strong></td></tr>
<tr><td>Judul</td><td>:</td><td>$trans[judul]</td></tr>
<tr><td>Pengarang</td><td>:</td><td>$trans[pengarang]</td></tr>
<tr><td>Penerbit</td><td>:</td><td>$trans[penerbit]</td></tr>
<tr><td>Tahun Terbit</td><td>:</td><td>$trans[thn_terbit]</td></tr>
<tr><td>Buku Kelas</td><td>:</td><td>$trans[kelasifikasi_buku]</td></tr>
<tr><td>Lokasi</td><td>:</td><td>$trans[lokasi]</td></tr>
<tr><td>Tanggal Input</td><td>:</td><td>$trans[tgl_input]</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
</td>

<td>
<div class='tooltip-demo'>
<a href='#' data-toggle='modal' data-target='#s$trans[no_induk]'>$trans[nama_siswa]</a>
<div class='modal fade' id='s$trans[no_induk]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-primary'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Siswa</h4>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='25%' rowspan='6'><img src='foto/$trans[foto_siswa]' height='133' width='100'></td>
<td width='25%'>No Induk</td><td width='10%'>:</td><td><strong>$trans[no_induk]</strong></td></tr>
<tr><td>Nama</td><td>:</td><td>$trans[nama_siswa]</td></tr>
<tr><td>Kelas</td><td>:</td><td>$trans[nama_kelas]</td></tr>
<tr><td>Jenis Kelamin</td><td>:</td><td>$jk</td></tr>
<tr><td>TTL</td><td>:</td><td>$trans[ttl]</td></tr>
<tr><td>Alamat</td><td>:</td><td>$trans[alamat]</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
</td>

<td>$trans[tgl_pinjam]</td>
<td><label class='label bg-primary'>kembali</label></td>

<td>
<div class='tooltip-demo'>
<a class='btn btn-xs btn-flat bg-blue' title='Detail' data-toggle='modal' data-target='#t$trans[id]'><i class='fa fa-bars'></i></a>
<div class='modal fade' id='t$trans[id]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-primary'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Transaksi</h4>
</div>
<div class='modal-body'>
<table width='100%' height='200' class='text-left'>
<tr><td width='25%'>Buku</td><td width='10%'>:</td><td>$trans[judul]</td></tr>
<tr><td>Siswa</td><td>:</td><td>$trans[nama_siswa]</td></tr>
<tr><td>Tgl Pinjam</td><td>:</td><td>$trans[tgl_pinjam]</td></tr>
<tr><td>Tgl Kembali</td><td>:</td><td>$trans[tgl_kembali]</td></tr>
<tr><td>Status</td><td>:</td><td><label class='label bg-primary'>kembali</label></td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn bg-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
</td>
</form>
</tr>
";
}?>
</tbody>
</table>
</div>
</div>                     
</div>
</div>
</section>
