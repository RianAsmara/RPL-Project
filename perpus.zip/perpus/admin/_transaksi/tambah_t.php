<section class="content-header">
          <h1>
              <i class="fa fa-retweet fa-fw"></i><small><b>TRANSAKSI BARU</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="pinjaman">Transaksi</a></li>
            <li class="active">Transaksi Baru</li>
          </ol>
        </section>
<section class="content">
<?php
$set=mysql_fetch_array(mysql_query("select * from setting"));
$date=date('d-m-Y');
$pecah			= explode("-",$date);
$next			= mktime(0,0,0,$pecah[1],$pecah[0]+$set[3],$pecah[2]);
$hari_next		= date("d-m-Y", $next);

if(isset($_POST['tambah'])){  
    $a=$_POST['kd_buku'];
    $b=$_POST['no_induk'];
    $e=$_POST['ket'];
$buku=mysql_num_rows(mysql_query("select * from buku where kode='$a' && status='1'"));
$siswa=mysql_num_rows(mysql_query("select * from siswa where no_induk='$b'"));
$row=mysql_num_rows(mysql_query("select * from trans where no_induk='$b' && status='pinjam'"));
$kasus=mysql_num_rows(mysql_query("select * from trans where no_induk='$b' && status='hilang'"));

if($buku==0){
echo "<div class='alert alert-warning alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Kode buku tidak tersedia
</div>";
}else if($siswa==0){
echo "<div class='alert alert-warning alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
No induk Siswa belum terdaftar
</div>";
}else if($kasus==1){
echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
ID anggota \"$b\" bermasalah, tidak di izinkan meminjam.
</div>";
}else if($row>=$set[2]){
echo "<div class='alert alert-warning alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Siswa tidak boleh meminjam buku lebih dari $set[2] kali.
</div>";
}else{
$z=mysql_query("INSERT INTO trans values('','$a','$b','$date','$hari_next','pinjam','$e')");
if($z){ 
mysql_query("update buku set status='0' where kode='$a'");
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Transaksi dengan kode buku \"$a\" berhasil ditambah. <a href='pinjaman' class='alert-link'>Lihat Data</a>
</div>";
}else{   
    echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div>";
}}}  
if(isset($_POST['tambah2'])){
$nama_siswa=strtoupper($_POST['nama_siswa']);
$kelas=$_POST['kelas'];
$judul_buku=$_POST['judul_buku'];
$jumlah=$_POST['jumlah'];
$date= date("d-m-Y");
$z=mysql_query("insert into trans2 values(NULL,'$nama_siswa','$kelas','$judul_buku','$jumlah','$date','1')");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Transaksi kelas berhasil, <a href='pinjaman_kelas' class='alert-link'>Lihat Data.</a>
</div>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div>";
}}
if(isset($_POST['tambah3'])){
$nama_guru=strtoupper($_POST['nama_guru']);
$diklat=$_POST['diklat'];
$judul_buku=$_POST['judul_buku'];
$jumlah=$_POST['jumlah'];
$date= date("d-m-Y");
$ket= $_POST['ket'];
$z=mysql_query("insert into trans3 values(NULL,'$nama_guru','$diklat','$judul_buku','$jumlah','$date','$ket','1')");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Transaksi guru berhasil, <a href='pinjaman_guru' class='alert-link'>Lihat Data.</a>
</div>";
}else{   
    echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div>";
}}    
?>
    
<div class="row">
<div class="col-md-3">
              <div class="box box-solid">
                <div class="box-body no-padding">
                  <ul class="nav nav-pills nav-stacked">
                    <li><a href="transaksi_anggota" class="bg-blue"><i class="fa fa-user"></i> Transaksi Anggota</a></li>
                    <li><a href="transaksi_kelas" class="bg-teal-active"><i class="fa  fa-users"></i> Transaksi Kelas</a></li>
                    <li><a href="transaksi_guru" class="bg-green"><i class="fa fa-user"></i> Transaksi Guru</a></li>
                  </ul>
                </div><!-- /.box-body -->
              </div><!-- /. box -->
</div>

<form role="form" method="post" enctype="multipart/form-data" action="">
<div class="col-md-9">
<?php
if(isset($_GET['ref'])){
$ref=$_GET['ref'];
if($ref=="transaksi_kelas"){?>
    <div class="box box-info">
        <div class="box-header">
            <h3 class="box-title">TRANSAKSI KELAS</h3>
        </div>
        <div class="box-body">
            <div class="form-group">
                <label>NAMA SISWA</label>
                <input type="text" class="form-control" name="nama_siswa" autofocus required>
            </div>
          
            <div class="form-group">
                <label>KELAS</label>
                <select name="kelas" class="form-control text-bold">
                <?php 
                    $q=mysql_query("select * from kelas order by nama_kelas");
                    while($kelas=mysql_fetch_array($q)){
                    echo "<option value=\"$kelas[0]\">$kelas[0]</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>JUDUL BUKU</label>
                <input type="text" class="form-control" name="judul_buku">
            </div>
            <div class="form-group">
                <label>JUMLAH</label>
                <input type="text" class="form-control" name="jumlah" autocomplete="off">
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-primary" name="tambah2">Transaksi</button>
                <button type="reset" class="btn btn-danger">Reset</button>
            </div>
        </div>
    </div><?php }else if($ref=="transaksi_anggota"){?>
    <div class="box box-primary">
        <div class="box-header">
            <h3 class="box-title">TRANSAKSI ANGGOTA</h3>
        </div>
        <div class="box-body">
            <div class="form-group">
                <label>KD. BUKU</label>
                <input type="text" class="form-control text-bold" id="kdbuku" name="kd_buku" autofocus required>
            </div>
          
            <div class="form-group">
                <label>NO. INDUK</label>
                <input type="text" class="form-control text-bold" id="noinduk" name="no_induk"  required>
            </div>
            <div class="form-group">
                <label>TANGGAL KEMBALI</label>
                <div class="input-group">
             <input type="text" class="form-control" value="<?php echo $hari_next?>" readonly>
              <span class="input-group-btn">
                <a href="setting" class="btn btn-default btn-flat"><i class="fa fa-gear"></i></a>
              </span>
            </div>
            </div>
            <div class="form-group">
                <label>KETERANGAN</label>
                <textarea name="ket"  class="form-control"></textarea>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-primary" name="tambah">Transaksi</button>
                <button type="reset" class="btn btn-danger">Reset</button>
            </div>
        </div>
    </div><?php }else if($ref=="transaksi_guru"){?>
    <div class="box box-success">
        <div class="box-header">
            <h3 class="box-title">TRANSAKSI GURU</h3>
        </div>
        <div class="box-body">
            <div class="form-group">
                <label>NAMA GURU</label>
                <input type="text" class="form-control" name="nama_guru" autofocus required>
            </div>
            <div class="form-group">
                <label>MATA DIKLAT</label>
                <input type="text" class="form-control" name="diklat"  required>
            </div>
            <div class="form-group">
                <label>JUDUL BUKU</label>
                <input type="text" class="form-control" name="judul_buku"  required>
            </div>
            <div class="form-group">
                <label>JUMLAH</label>
                <input type="text" class="form-control" name="jumlah"  required>
            </div>
            <div class="form-group">
                <label>KET.</label>
                <textarea name="ket"  class="form-control"></textarea>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn btn-primary" name="tambah3">Transaksi</button>
                <button type="reset" class="btn btn-danger">Reset</button>
            </div>
        </div>
    </div>
    <?php }}?>
    
</div>
</div>
</div>
</section>
<script>
    <?php include('lib/dataauto.php') ?>
$("#kdbuku" ).autocomplete({
	source: KodeBuku
})
$("#noinduk" ).autocomplete({
	source: NoInduk
})
</script>