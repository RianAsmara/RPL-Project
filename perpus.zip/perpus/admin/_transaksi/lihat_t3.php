<section class="content-header">
          <h1>
              <a href="transaksi_guru" title="Transaksi Guru"><i class="fa fa-retweet fa-fw"></i></a><small><b>TRANSAKSI</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Transaksi</li>
          </ol>
        </section>
<section class="content">
<div class="row">
<div class="col-xs-12">
<?php
if(isset($_POST['edit1'])){
$id=$_POST['idtrans'];
$data=mysql_fetch_array(mysql_query("select * from trans3 where id='$id'"));
?>  <form method="post">
    <div class="box box-success">
        <div class="box-header">
            <h3 class="box-title">TRANSAKSI GURU</h3>
            <div class="box-tools pull-right">
        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
    </div>
        </div>
        <div class="box-body">
            <div class="form-group">
                <label>NAMA GURU</label>
                <input type="hidden" name="idtrans" value="<?php echo $data[0]?>">
                <input type="text" class="form-control" name="nama_guru" value="<?php echo $data[1]?>" required>
            </div>
            <div class="form-group">
                <label>MATA DIKLAT</label>
                <input type="text" class="form-control" name="diklat" value="<?php echo $data[2]?>" required>
            </div>
            <div class="form-group">
                <label>JUDUL BUKU</label>
                <input type="text" class="form-control" name="judul_buku" value="<?php echo $data[3]?>" required>
            </div>
            <div class="form-group">
                <label>JUMLAH</label>
                <input type="text" class="form-control" name="jumlah" value="<?php echo $data[4]?>" required>
            </div>
            <div class="form-group">
                <label>KET.</label>
                <textarea name="ket"  class="form-control"><?php echo $data[6]?></textarea>
            </div>
            <div class="box-footer">
                <button type="submit" class="btn bg-olive" name="edit2">Ubah</button>
                <button type="reset" class="btn btn-danger">Reset</button>
            </div>
        </div>
    </div></form><?php
}
if(isset($_POST['kembali'])){
$idtrans=$_POST['idtrans'];
$nama_guru=$_POST['nama_guru'];
$z=mysql_query("update trans3 set status='0' where id='$idtrans'");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Berhasil, \"$nama_guru\" telah mengambalikan buku.</div>";
}}
if(isset($_POST['edit2'])){
$id=$_POST['idtrans'];
$nama_guru=$_POST['nama_guru'];
$diklat=$_POST['diklat'];
$judul_buku=$_POST['judul_buku'];
$jumlah=$_POST['jumlah'];
$diklat=$_POST['diklat'];
$ket=$_POST['ket'];
$z=mysql_query("update trans3 set nama_guru='$nama_guru',diklat='$diklat',judul_buku='$judul_buku',jumlah='$jumlah',ket='$ket' where id='$id'");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Berhasil, Transaksi \"$nama_guru\" telah diubah.</div>";
}}?>
<div class="box box-primary">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="Dtable" class="table table-bordered table-striped table-hover">
                    <thead>
                      <tr>
                        <th>NO</th>
                        <th>NAMA</th>
                        <th>BUKU</th>
                        <th>TGL.PINJAM</th>
                        <th>KET</th>
                        <th>ACTION</th>
                        
                      </tr>
                    </thead>
                    <tbody>
<?php 
$qtrans=mysql_query("select * from trans3 where status='1' order by id");
$no=0;
while($trans=mysql_fetch_array($qtrans)){
$no++;?>
<tr class="text-center">
<form method="post">
<td><?php echo $no?><input type="hidden" name="idtrans" value="<?php echo $trans['id']?>"></td>
<td><?php echo strtoupper($trans['nama_guru'])?><input type="hidden" name="nama_guru" value="<?php echo $trans['nama_guru']?>"></td>
<td><?php echo strtoupper($trans['judul_buku'])?> <b class="text-primary">(<?php echo strtoupper($trans['jumlah'])?>)</b></td>
<td><?php echo $trans['tgl_pinjam']?></td>
<td><?php echo $trans['ket']?></td>
<td>
<button title="Kembali" type="submit" name="kembali" class="btn btn-xs btn-flat btn-primary" onclick="return confirm('Anda yakin ingin mengembalikan buku <?php echo $trans['judul_buku']?>')"><i class="fa fa-check"></i></button>
<button title="Edit" type="submit" name="edit1" class="btn btn-xs btn-flat bg-olive"><i class="fa fa-edit"></i></button>
</form>
</tr><?php }?>
</tbody>
</table>
</div>                                      
</div>
</div>
</div>
</section>