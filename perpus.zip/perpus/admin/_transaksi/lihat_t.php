<section class="content-header">
          <h1>
              <a href="transaksi_anggota" title="Transaksi Baru"><i class="fa fa-retweet fa-fw"></i></a><small><b>TRANSAKSI</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Transaksi</li>
          </ol>
        </section>
 <section class="content">
<?php
$set=mysql_fetch_array(mysql_query("select * from setting"));
if(isset($_POST['kembali'])){
$id=$_POST['id'];
$kode=$_POST['kode'];
$buku=$_POST['judul'];
$z=mysql_query("update trans set status='kembali' where id='$id'");
mysql_query("update buku set status='1' where kode='$kode'");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Buku \"$buku\" berhasil di kembalikan
</div>";
}else{   
    echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div>";
}}

if(isset($_POST['hilang'])){
$id=$_POST['id'];
$kode=$_POST['kode'];
$buku=$_POST['judul'];
$z=mysql_query("update trans set status='hilang' where id='$id'");
mysql_query("update buku set status='-1' where kode='$kode'");
if($z){ 
    echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Buku \"$buku\" telah dimasukan kedaftar hilang. <a href='buku_hilang' class='alert-link'>Lihat Daftar Hilang</a>
</div>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div></h5>";
}}


if(isset($_POST['perpanjang'])){
$id=$_POST['id'];
$buku=$_POST['judul'];
$tgl_kembali=$_POST['tgl_kembali'];
$pecah			= explode("-",$tgl_kembali);
$next			= mktime(0,0,0,$pecah[1],$pecah[0]+$set[3],$pecah[2]);
$hari_next		= date("d-m-Y", $next);

$z=mysql_query("update trans set tgl_kembali='$hari_next' where id='$id'");
if($z){ 
    echo "<h5><div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Buku \"$buku\" berhasil di perpanjang
</div></h5>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Gagal, ".mysql_error()."
</div></h5>";
}}
 ?>

 <div class="row">
            <div class="col-xs-12">
              <div class="box box-primary">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="Dtable" class="table table-bordered table-striped table-hover">
                    <thead>
                      <tr>
                        <th>NO</th>
                        <th>SISWA</th>
                        <th>BUKU</th>
                        <th>TGL.KEMBALI</th>
                        <th>DENDA</th>
                        <th>ACTION</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
$qtrans=mysql_query("select kelas.*, buku_kelas.*, trans.*, siswa.*, buku.* from kelas, buku_kelas, trans, siswa, buku where kelas.nama_kelas=siswa.kelas && buku_kelas.kelasifikasi_buku=buku.kelasifikasi_buku && siswa.no_induk=trans.no_induk && buku.kode=trans.kode && trans.status='pinjam' order by id desc");
$no=0;
while($trans=mysql_fetch_array($qtrans)){
$no++;
$sekarang = date ("d-m-Y");
$p= explode ("-", $trans['tgl_kembali']);
$d = $p[0];
$m = $p[1];
$y = $p[2];
$p2= explode ("-", $sekarang); 
$d2 = $p2[0];
$m2 = $p2[1];
$y2 = $p2[2];
$date1 = gregoriantojd($m, $d, $y);
$date2 = gregoriantojd($m2, $d2, $y2);
$selisih=$date2-$date1;
if($selisih>=1){
$telat="<a class='text-danger'>$selisih hari</a>";
}else{
$telat="0 hari";
}
if ($date2>$date1){
$a = $selisih*$set[1];
$denda = "<strong class='text-danger'>Rp.$a</strong>";
$b = "warning";
}
else {
$denda = "-";
$b = "";
}
if($trans['jk']=='L'){
$jk='Laki - laki';
}else{
$jk='Perempuan';
}

echo "<tr class='text-center $b'>
<form method='post'>
<td>$no</td>
<td><input type='hidden' value='$trans[no_induk]' name='nama_siswa'>
<div class='tooltip-demo'>
<a href='#' data-toggle='modal' data-target='#s$trans[no_induk]'>";echo strtoupper($trans['nama_siswa']);echo"</a>
<div class='modal fade' id='s$trans[no_induk]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-primary'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Siswa</h4>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='25%' rowspan='6'><img src='foto/$trans[foto_siswa]' height='133' width='100'></td>
<td width='25%'>No Induk</td><td width='10%'>:</td><td><strong>$trans[no_induk]</strong></td></tr>
<tr><td>Nama</td><td>:</td><td>";echo strtoupper($trans['nama_siswa']); echo "</td></tr>
<tr><td>Kelas</td><td>:</td><td>$trans[nama_kelas]</td></tr>
<tr><td>Jenis Kelamin</td><td>:</td><td>$jk</td></tr>
<tr><td>TTL</td><td>:</td><td>$trans[ttl]</td></tr>
<tr><td>Alamat</td><td>:</td><td>$trans[alamat]</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-info' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
</td>
<td><input type='hidden' value='$trans[id]' name='id'><input type='hidden' value='$trans[kode]' name='kode'>
<div class='tooltip-demo'>
<a href='#' data-toggle='modal' data-target='#b$trans[kode]'>$trans[judul]<input type='hidden' value='$trans[judul]' name='judul'></a>
<div class='modal fade' id='b$trans[kode]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-primary'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Buku</h4>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='35%' rowspan='9'><img src='foto/$trans[foto_buku]' height='230' width='150'></td>
<td width='25%'>Kode Buku</td><td width='10%'>:</td><td><strong>$trans[kode]</strong></td></tr>
<tr><td>Judul</td><td>:</td><td>$trans[judul]</td></tr>
<tr><td>Pengarang</td><td>:</td><td>$trans[pengarang]</td></tr>
<tr><td>Penerbit</td><td>:</td><td>$trans[penerbit]</td></tr>
<tr><td>Tahun Terbit</td><td>:</td><td>$trans[thn_terbit]</td></tr>
<tr><td>Buku Kelas</td><td>:</td><td>$trans[kelasifikasi_buku]</td></tr>
<tr><td>Lokasi</td><td>:</td><td>$trans[lokasi]</td></tr>
<tr><td>Tanggal Input</td><td>:</td><td>$trans[tgl_input]</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
</td>
<td>$trans[tgl_kembali]</td>
<td>$denda</td>

<td>
<div class='tooltip-demo'>
<a class='btn btn-xs bg-blue disable btn-flat' title='Detail' data-toggle='modal' data-target='#t$trans[id]'><i class='fa fa-bars'></i></a>
<div class='modal fade' id='t$trans[id]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-primary'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h4 class='modal-title' id='myModalLabel'>Detail Transaksi</h4>
</div>
<div class='modal-body'>
<table width='90%' height='200' align='center' class='text-left'>
<tr><td width='30%'>Buku</td><td width='20%'>:</td><td>$trans[judul]</td></tr>
<tr><td> Siswa</td><td>:</td><td>$trans[nama_siswa]</td></tr>
<tr><td> Tgl Pinjam</td><td>:</td><td><em class='text-primary'>$trans[tgl_pinjam]</em></td></tr>
<tr><td> Tgl Kembali</td><td>:</td><td><em class='text-primary'>$trans[tgl_kembali]
<input type='hidden' value='$trans[tgl_kembali]' name='tgl_kembali'></em></td></tr>
<tr><td> Telat</td><td>:</td><td>$telat</td></tr>
<tr><td> Denda</td><td>:</td><td>$denda</td></tr>
<tr><td> Status</td><td>:</td><td><label class='label bg-green'>Pinjam</label></td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
<button type='submit' title='Perpanjang' name='perpanjang' class='btn btn-xs btn-info btn-flat' onclick='return confirm(\"Anda yakin ingin perpanjang buku $trans[judul] ?\")'><i class='fa fa-upload'></i></button>
<button title='Kembali' type='submit' name='kembali' class='btn btn-xs btn-flat  btn-primary' onclick='return confirm(\"Anda yakin ingin mengembalikan buku $trans[judul] ?\")'><i class='fa fa-check'></i></button>
<button title='Hilang' type='submit' name='hilang' class='btn btn-xs btn-danger  btn-flat' onclick='return confirm(\"Anda yakin buku $trans[judul] hilang ?\")'><i class='fa fa-times'></i></button>
</td>
</form>
</tr>
";
}?>
</tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->