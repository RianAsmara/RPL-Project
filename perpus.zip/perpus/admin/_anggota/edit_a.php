<?php
if(isset($_POST['hapus'])){
$id=$_POST['id'];
$nama=$_POST['nama_siswa'];
$foto=$_POST['foto_siswa'];
if($foto!=""){unlink("../foto/$foto");}
$z=mysql_query("delete from siswa where no_induk='$id'");
if($z){ 
    echo "<h5><div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
<p>Data \"$nama\" berhasil dihapus.</p>
</div></h5>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
<p>Gagal, ".mysql_error()."</p>
</div></h5>";
}}
if(isset($_POST['edit'])){
$id=$_POST['no_induk'];
$siswa=mysql_fetch_array(mysql_query("select * from siswa where no_induk='$id'"));
    $a=$_POST['no_induk'];
    $b=strtoupper(mysql_real_escape_string($_POST["nama_siswa"]));
    $c=$_POST['kelas'];
    $d=$_POST['jk'];
    $e=$_POST['ttl'];
    $f=$_POST['alamat'];
	$file=$_FILES['file']['name'];
if($file==""){
$z=mysql_query("update siswa set nama_siswa='$b', kelas='$c', jk='$d', ttl='$e', alamat='$f' where no_induk='$a'");	
}else{
if($siswa[6]!=""){unlink("../foto/$siswa[6]");}
$upload = "../foto/$a." . basename($_FILES['file']['name']);
$simpan = "$a." . basename($_FILES['file']['name']);   
move_uploaded_file($_FILES['file']['tmp_name'], $upload);		
$z=mysql_query("update siswa set nama_siswa='$b', kelas='$c', jk='$d', ttl='$e', alamat='$f', foto_siswa='$simpan' where no_induk='$a'");
}
$b2=stripslashes($b);
if($z){ 
    echo "<h5><div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
<p>Data \"$b2\" berhasil di update.</p>
</div></h5>";
}else{   
    echo "<h5><div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
<p>Gagal, ".mysql_error()."</p>
</div></h5>";
}}

if(isset($_POST['update'])){ 
$id=$_POST['id'];
$siswa=mysql_fetch_array(mysql_query("select * from siswa where no_induk='$id'"));
?>
<div class="row">
<form role="form" method="post" enctype="multipart/form-data" action="">
<div class="col-md-6">
<div class="box box-success">
<div class="box-header">
    <h3 class="box-title">UBAH <small>INFORMASI UMUM</small></h3>
    <div class="box-tools pull-right">
        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
    </div>
</div>
<div class="box-body">
    <div class="form-group">
        <label>NO. INDUK</label>
        <input type="text" class="form-control" value="<?php echo $siswa['no_induk'] ?>" autocomplete="off" name="no_induk" placeholder="ex. 2604"  required readonly>
    </div>
    <div class="form-group">
        <label>NAMA LENGKAP</label>
        <input type="text" class="form-control" value="<?php echo $siswa['nama_siswa'] ?>" name="nama_siswa" autocomplete="off" placeholder="ex.  FIRMAN PANTI GELEN" required>
    </div>
    <div class="form-group">
        <label>KELAS</label>
        <select class="form-control text-bold" name="kelas" required>
<?php
$qkelas=mysql_query("select * from kelas");
while($kelas=mysql_fetch_array($qkelas)){
if($kelas['nama_kelas']==$siswa['kelas']){
$selected='selected';
} else {
$selected='';
}
echo"
<option value='$kelas[nama_kelas]' $selected>$kelas[nama_kelas]</option>
";}?>      
      </select>
    </div>
    <div class="form-group">
        <label>JENIS KELAMIN</label>
        <div class="radio">
        <?php if($siswa['jk']=='L'){ ?>
                <label>
                    <input type="radio" name="jk" value="L" checked>Laki-Laki.
                </label>
                <label>
                    <input type="radio" name="jk" value="P">Perempuan.
                </label>
        <?php }else{?>
                <label>
                    <input type="radio" name="jk" value="L">Laki-Laki.
                </label>
                <label>
                    <input type="radio" name="jk" value="P" checked>Perempuan.
                </label>
        <?php }?>
            </div></div>
        <div class="form-group">
        <label>TTL</label>
            <input type="text" class="form-control" value="<?php echo $siswa['ttl'] ?>" name="ttl" placeholder="ex. Langko, 26 maret 1997" autocomplete="off" required>
    </div>                       
</div>
</div>
</div>
    
    <div class="col-md-6">
<div class="box box-success">
<div class="box-header">
    <h3 class="box-title">UBAH <small>INFORMASI TAMBAHAN</small></h3>
    <div class="box-tools pull-right">
        <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
    </div>
</div>
<div class="box-body">
    <div class="form-group">
    <div class="col-xs-7">
      <label>FOTO</label>
      <input type="file" name="file" id="preview_gambar">
      <p class="help-block">Gunakan foto Reolusi 3X4</p>
        </div>
    <div class="col-xs-5">
        <div class="box box-danger text-center">
            <div class="box-header"></div>
        <img src="foto/<?php echo $siswa['foto_siswa'] ?>" id="gambar_nodin" height="151" width="120"/>
            <div class="box-footer"> Preview </div>
<script>
    function bacaGambar(input) {
   if(input.files && input.files[0]){
      var reader = new FileReader();
      reader.onload = function (e) {
          $('#gambar_nodin').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
   }
}
</script>
        </div>
        </div>
    </div>
    <div class="form-group">
      <label>ALAMAT</label>
      <textarea class="form-control" name="alamat" rows="1" placeholder="ex. Langko, kec.Janapria"><?php echo $siswa['alamat'] ?></textarea>
    </div>                             
</div>
    <div class="box-footer">
        <button type="submit" class="btn btn-primary" name="edit">Update</button>
        <button type="reset" class="btn btn-danger">Reset</button>
    </div>
</div>
</div>
</form>
</div>
<?php }?>