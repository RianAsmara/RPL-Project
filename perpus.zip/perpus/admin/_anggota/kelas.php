<section class="content-header">
          <h1>
              <i class="fa fa-user fa-fw"></i><small><b>KELAS</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="anggota">Anggota</a></li>
            <li class="active">Kelas</li>
          </ol>
        </section>
<section class="content">
<?php
if(isset($_POST['tambah'])){
$namakelas=$_POST['nama_kelas'];
$z=mysql_query("insert into kelas values('$namakelas')");
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
<p>Kelas \"$namakelas\" berhasil ditambah.</p>
</div>";
}else{   
    echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
<p>Gagal, ".mysql_error()."</p>
</div>";
}}

if(isset($_POST['hapus'])){
$kelas=$_POST['nama_kelas'];
$z=mysql_query("delete from kelas where nama_kelas='$kelas'");
if($z){ 
    echo "<h5><div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
Kelas \"$kelas\" berhasil dihapus
</div></h5>";
}}
?>

<div class="row">
<div class="col-md-3">
<div class="box box-warning">
<div class="box-body">
<form method="post">
<label>Tambah</label>
<div class="form-group input-group">
<input type="text" name="nama_kelas" class="form-control" placeholder='Nama Kelas' required>
<span class="input-group-btn">
<button class="btn btn-primary" name="tambah" type="submit"><strong>+</strong>
</button>
</span>
</div>
</form>
</div>
</div>
</div>
    
    <div class="col-md-9">
<div class="box box-warning">
<div class="box-header">
</div>
<div class="box-body">
    <table id="Dtable" class="table table-bordered table-striped table-hover text-center">
        <thead>
          <tr>
            <th>NO</th>
            <th>NAMA</th>
            <th>ANGGOTA</th>
            <th>ACTION</th>
          </tr>
        </thead>
        <tbody>
            <?php 
$qkelas=mysql_query("select * from kelas");
$no=0;
while($kelas=mysql_fetch_array($qkelas)){
    $count=mysql_num_rows(mysql_query("select kelas from siswa where kelas='$kelas[nama_kelas]'"));
    if($count==0){
        $data="0";
    }else{$data="<label class='label bg-green'>$count</label>";}
$no++;
echo"<tr>
<form method='post'>
<td width='50'>$no</td>
<td>$kelas[nama_kelas]<input type='hidden' name='nama_kelas' value='$kelas[nama_kelas]'></td>
<td>$data</td>
<td>
<button type='submit' name='hapus' class='btn btn-xs btn-danger btn-flat' onclick='return confirm(\"Anda yakin ingin menghapus kelas $kelas[nama_kelas]  ?\")'><i class='fa fa-trash-o'></i></button>
</td>
</form>
</tr>";}?>
        </tbody>
    </table>
</div>
</div>
</div>
</div>
</section>