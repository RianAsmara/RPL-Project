<section class="content-header">
          <h1>
              <i class="fa fa-user fa-fw"></i><small><b>TAMBAH ANGGOTA BARU</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="anggota">Anggota</a></li>
            <li class="active">Tambah anggota</li>
          </ol>
        </section>
<section class="content">
<?php
if(isset($_POST['tambah'])){
    
    $a=$_POST['no_induk'];
    $b=mysql_real_escape_string($_POST["nama_siswa"]);
    $c=$_POST['kelas'];
    $d=$_POST['jk'];
    $e=$_POST['ttl'];
    $f=$_POST['alamat'];
    
if(!empty($_FILES['file']['name'])){
$upload = "../foto/$a." . basename($_FILES['file']['name']);
$simpan = "$a." . basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'], $upload);
$z=mysql_query("INSERT INTO siswa values('$a','$b','$c','$d','$e','$f','$simpan')");
}else{
$z=mysql_query("INSERT INTO siswa values('$a','$b','$c','$d','$e','$f','')");
}
$b2=stripslashes($b);
if($z){ 
    echo "<div class='alert alert-info alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button><p>
Data \"$b2\" berhasil ditambah. <a href='anggota' class='alert-link'>Lihat Data</a></p>
</div>";
}else{   
    echo "<div class='alert alert-danger alert-dismissable'>
<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
<p>Gagal, ".mysql_error()."<p>
</div>";
}} ?>
<div class="row">
<form role="form" method="post" enctype="multipart/form-data" action="">
<div class="col-md-6">
<div class="box box-info">
<div class="box-header">
<h3 class="box-title">INFORMASI UMUM</h3>
</div>
<div class="box-body">

    
    <div class="form-group">
        <label>NO. INDUK</label>
        <input type="text" class="form-control" autocomplete="off" name="no_induk" placeholder="ex. 2604" autofocus required>
    </div>
    <div class="form-group">
        <label>NAMA LENGKAP</label>
        <input type="text" class="form-control" name="nama_siswa" autocomplete="off" placeholder="ex.  FIRMAN PANTI GELEN" required>
    </div>
    <div class="form-group">
        <label>KELAS</label>
        <select class="form-control text-bold" name="kelas" required>
<?php
$qkelas=mysql_query("select * from kelas");
while($kelas=mysql_fetch_array($qkelas)){
echo"
<option value='$kelas[nama_kelas]'>$kelas[nama_kelas]</option>
";}?>       
      </select>
    </div>
    <div class="form-group">
        <label>JENIS KELAMIN</label>
            <div class="radio">
                <label>
                    <input type="radio" name="jk" value="L" checked>Laki-Laki.
                </label>
                <label>
                    <input type="radio" name="jk" value="P">Perempuan.
                </label>
        </div></div>
        <div class="form-group">
        <label>TANGGAL LAHIR</label>
            <input type="text" class="form-control" name="ttl" placeholder="ex. 26 maret 1997" autocomplete="off" required>
    </div>                        
</div>
</div>
</div>
    
    <div class="col-md-6">
<div class="box box-info">
<div class="box-header">
<h3 class="box-title">INFORMASI TAMBAHAN</h3>
</div>
<div class="box-body">
    <div class="form-group">
    <div class="col-xs-7">
      <label for="exampleInputFile">FOTO</label>
      <input type="file" name="file" id="preview_gambar">
      <p class="help-block">Gunakan foto Reolusi 3x4</p>
        </div>
    <div class="col-xs-5">
        <div class="box box-danger text-center">
            <div class="box-header"></div>
        <img src="#" id="gambar_nodin" height="151" width="120"/>
            <div class="box-footer"> Preview </div>
<script>
    function bacaGambar(input) {
   if(input.files && input.files[0]){
      var reader = new FileReader();
      reader.onload = function (e) {
          $('#gambar_nodin').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
   }
}
</script>
        </div>
        </div>
    </div>
    <div class="form-group">
      <label>ALAMAT</label>
      <textarea class="form-control" name="alamat" rows="1" placeholder="ex. Langko, kec.Janapria"></textarea>
    </div>                             
</div>
    <div class="box-footer">
        <button type="submit" class="btn btn-primary " name="tambah">Tambah</button>
        <button type="reset" class="btn btn-danger">Reset</button>
    </div>
</div>
</div>
</form>
</div>
</section>