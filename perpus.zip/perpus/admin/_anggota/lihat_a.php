<section class="content-header">
          <h1>
              <a href="tambah_anggota" title="Tambah Anggota Baru"><i class="fa fa-user fa-fw"></i></a><small><b>DATA ANGGOTA</b></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Anggota</li>
          </ol>
        </section>
 <section class="content">
<?php include ('_anggota/edit_a.php')?>
     <div class="row">
            <div class="col-xs-12">
              <div class="box box-primary">
                <div class="box-header">
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="Dtable" class="table table-bordered table-striped table-hover">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>NAMA</th>
                        <th>KELAS</th>
                        <th>JK</th>
                        <th>ACTION</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
$qsiswa=mysql_query("select kelas.*, siswa.* from siswa, kelas where kelas.nama_kelas=siswa.kelas");
while($siswa=mysql_fetch_array($qsiswa)){
if($siswa['jk']=='L'){
$jk='Laki - laki';
}else{
$jk='Perempuan';
}
echo "<tr class='text-center'>
<form method='post'>
<td>$siswa[no_induk]<input type='hidden' value='$siswa[no_induk]' name='id'></td>
<td>"; echo strtoupper($siswa['nama_siswa']);echo "<input type='hidden' value='$siswa[nama_siswa]' name='nama_siswa'></td>
<td>$siswa[nama_kelas]</td>
<td>$siswa[jk]</td>        
<td>
<div class='tooltip-demo'>
<button type='button' class='btn btn-xs btn-flat bg-blue' data-toggle='modal' data-target='#$siswa[no_induk]'><i class='fa fa-bars'></i></button>
<div class='modal fade' id='$siswa[no_induk]' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header bg-primary'>
<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
<h5 class='modal-title' id='myModalLabel'>DETAIL ANGGOTA</h5>
</div>
<div class='modal-body'>
<table width='100%' class='text-left'>
<tr><td width='25%' rowspan='6'><input type='hidden' value='$siswa[foto_siswa]' name='foto_siswa'><img src='foto/$siswa[foto_siswa]' height='151' width='120'></td>
<td width='25%'>No Induk</td><td width='10%'>:</td><td><strong>$siswa[no_induk]</strong></td></tr>
<tr><td>Nama</td><td>:</td><td>$siswa[nama_siswa]</td></tr>
<tr><td>Kelas</td><td>:</td><td>$siswa[nama_kelas]</td></tr>
<tr><td>Jenis Kelamin</td><td>:</td><td>$jk</td></tr>
<tr><td>TTL</td><td>:</td><td>$siswa[ttl]</td></tr>
<tr><td>Alamat</td><td>:</td><td>$siswa[alamat]</td></tr>
</table>
</div>
<div class='modal-footer'>
<button type='button' class='btn btn-primary' data-dismiss='modal'>Keluar</button>
</div>
</div>
</div>
</div>
<button type='submit' name='update' class='btn btn-xs bg-olive btn-flat'><i class='fa fa-edit'></i></button>
<button type='submit' name='hapus' class='btn btn-xs bg-red btn-flat' onclick='return confirm(\"Anda yakin ingin menghapus $siswa[nama_siswa] ?\")'><i class='fa fa-trash-o'></i></button>
</div></td>
</form>
</tr>
";
}?>
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->