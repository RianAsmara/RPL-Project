<?php
session_start();
include 'admin/lib/koneksi.php';
$pass = md5(mysql_real_escape_string($_POST['password']));
$row=mysql_num_rows(mysql_query("select * from user where password='$pass'"));
    if($row==1){
        $_SESSION['login'] = $pass;
        header('location:home');
    }else{
        header('location:login=error');
    }
?>